#!/usr/bin/env python3
"""
Test script for the offline AI chatbot
Tests all components: NLP engine, ML models, chat memory, and main chatbot
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.offline_nlp_engine import OfflineNLPEngine
from utils.offline_ml_models import OfflineMLModels
from utils.chat_memory import ChatMemory
from utils.offline_chatbot import OfflineChatbot

def test_nlp_engine():
    """Test the NLP engine"""
    print("🧠 Testing NLP Engine...")
    
    nlp = OfflineNLPEngine(None)  # Pass None for db_session
    
    # Test queries
    test_queries = [
        "What is the current stock of apples?",
        "Show me sales for last week",
        "Which suppliers are delayed?",
        "Create a task to reorder milk",
        "What products are low in stock?"
    ]
    
    for query in test_queries:
        result = nlp.parse_query(query)
        print(f"Query: '{query}'")
        print(f"Intent: {result['intent']}, Entities: {result['entities']}")
        print()
    
    print("✅ NLP Engine test completed!\n")

def test_chat_memory():
    """Test the chat memory system"""
    print("💾 Testing Chat Memory...")
    
    memory = ChatMemory()
    
    # Test adding messages
    memory.add_message("user", "Hello", "greeting")
    memory.add_message("assistant", "Hi! How can I help you?", "greeting")
    memory.add_message("user", "Show stock levels", "stock_query")
    
    # Test context retrieval
    context = memory.get_context()
    print(f"Context messages: {len(context)}")
    
    # Test search
    search_results = memory.search_history("stock")
    print(f"Search results for 'stock': {len(search_results)}")
    
    print("✅ Chat Memory test completed!\n")

def test_ml_models():
    """Test the ML models (without database)"""
    print("🤖 Testing ML Models...")
    
    try:
        # Test with None database session (will use fallback methods)
        models = OfflineMLModels(None)
        
        # Test fallback predictions (when no data available)
        sales_pred = models.predict_sales(days_ahead=7)
        print(f"Sales prediction: {sales_pred['status']}")
        
        demand_pred = models.predict_product_demand()
        print(f"Product demand prediction: {demand_pred['status']}")
        
        print("✅ ML Models test completed!\n")
    except Exception as e:
        print(f"⚠️ ML Models test failed: {e}\n")

def test_chatbot():
    """Test the main chatbot"""
    print("🤖 Testing Main Chatbot...")
    
    try:
        # Test with None database session (will use fallback methods)
        chatbot = OfflineChatbot(None)
        
        # Test queries (avoid DB-heavy intents for standalone test)
        test_messages = [
            "Hello",
            "Help",
            "What can you do?",
            "What's the weather like?"  # Out of domain
        ]
        
        for message in test_messages:
            response = chatbot.process_message(message, user_id=1)
            print(f"User: {message}")
            print(f"Bot: {response.get('response', '')[:100]}...")
            print(f"Intent: {response.get('intent', '')}")
            print()
        
        print("✅ Main Chatbot test completed!\n")
    except Exception as e:
        print(f"⚠️ Chatbot test failed: {e}\n")

def main():
    """Run all tests"""
    print("🚀 Starting Offline AI Chatbot Tests...\n")
    
    test_nlp_engine()
    test_chat_memory()
    test_ml_models()
    test_chatbot()
    
    print("🎉 All tests completed!")
    print("\n📋 Summary:")
    print("✅ NLP Engine: Working")
    print("✅ Chat Memory: Working")
    print("⚠️ ML Models: Requires database connection")
    print("⚠️ Main Chatbot: Requires database connection")
    print("\n🔧 To fully test with database, run the Flask app and use the web interface.")

if __name__ == "__main__":
    main()