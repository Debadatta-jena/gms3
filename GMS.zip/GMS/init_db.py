from app import app, db, bcrypt
from models.user import User, UserLog
from models.product import Category, Product
from models.supplier import Supplier
from models.order import Order, OrderItem
import datetime

def init_db():
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Check if admin user exists
        if User.query.filter_by(username='admin').first() is None:
            # Create admin user
            admin = User(
                username='admin',
                email='admin@gms.com',
                role='admin'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            
            # Create staff user
            staff = User(
                username='staff',
                email='staff@gms.com',
                role='staff'
            )
            staff.set_password('staff123')
            db.session.add(staff)
            
            # Create categories
            categories = [
                Category(name='Dairy', description='Milk, cheese, butter, etc.'),
                Category(name='Bakery', description='Bread, cakes, pastries, etc.'),
                Category(name='Beverages', description='Soft drinks, juices, water, etc.'),
                Category(name='Snacks', description='Chips, cookies, nuts, etc.'),
                Category(name='Fruits', description='Fresh fruits'),
                Category(name='Vegetables', description='Fresh vegetables')
            ]
            db.session.add_all(categories)
            
            # Create suppliers
            suppliers = [
                Supplier(
                    name='Dairy Farm Inc.',
                    contact_person='John Doe',
                    email='john@dairyfarm.com',
                    phone='123-456-7890',
                    address='123 Milk St, Dairy Town',
                    reliability_rating=4.8
                ),
                Supplier(
                    name='Fresh Bakery Co.',
                    contact_person='Jane Smith',
                    email='jane@freshbakery.com',
                    phone='234-567-8901',
                    address='456 Bread Ave, Baker City',
                    reliability_rating=4.5
                ),
                Supplier(
                    name='Beverage World',
                    contact_person='Bob Johnson',
                    email='bob@beverageworld.com',
                    phone='345-678-9012',
                    address='789 Drink Blvd, Soda Springs',
                    reliability_rating=4.2
                )
            ]
            db.session.add_all(suppliers)
            
            # Commit to get IDs
            db.session.commit()
            
            # Get category and supplier IDs
            dairy_id = Category.query.filter_by(name='Dairy').first().id
            bakery_id = Category.query.filter_by(name='Bakery').first().id
            beverages_id = Category.query.filter_by(name='Beverages').first().id
            
            supplier1_id = Supplier.query.filter_by(name='Dairy Farm Inc.').first().id
            supplier2_id = Supplier.query.filter_by(name='Fresh Bakery Co.').first().id
            supplier3_id = Supplier.query.filter_by(name='Beverage World').first().id
            
            # Create products
            products = [
                Product(
                    name='Milk 1L',
                    barcode='1234567890123',
                    category_id=dairy_id,
                    supplier_id=supplier1_id,
                    purchase_price=0.80,
                    selling_price=1.20,
                    quantity=50,
                    reorder_level=10,
                    expiry_date=datetime.date.today() + datetime.timedelta(days=7)
                ),
                Product(
                    name='Bread',
                    barcode='2345678901234',
                    category_id=bakery_id,
                    supplier_id=supplier2_id,
                    purchase_price=1.00,
                    selling_price=1.50,
                    quantity=30,
                    reorder_level=5,
                    expiry_date=datetime.date.today() + datetime.timedelta(days=3)
                ),
                Product(
                    name='Cola 500ml',
                    barcode='3456789012345',
                    category_id=beverages_id,
                    supplier_id=supplier3_id,
                    purchase_price=0.50,
                    selling_price=1.00,
                    quantity=100,
                    reorder_level=20,
                    expiry_date=datetime.date.today() + datetime.timedelta(days=180)
                )
            ]
            db.session.add_all(products)
            
            # Commit changes
            db.session.commit()
            
            print("Database initialized with sample data!")
        else:
            print("Database already contains data. Skipping initialization.")

if __name__ == '__main__':
    init_db()