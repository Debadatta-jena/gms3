from flask import Flask, render_template, redirect, url_for
from flask import Blueprint
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'demo-secret'

# ---- Demo context: inject a fake authenticated user and current time ----
class DemoUser:
    def __init__(self, username='Demo Admin', role='admin'):
        self.username = username
        self.role = role
        self.is_authenticated = True

@app.context_processor
def inject_demo_context():
    return {
        'current_user': DemoUser(),
        'now': datetime.now()
    }

# ---- Demo data classes ----
class DemoCategory:
    def __init__(self, name):
        self.name = name

class DemoSupplier:
    def __init__(self, id, name, contact_person, email, phone, products=None):
        self.id = id
        self.name = name
        self.contact_person = contact_person
        self.email = email
        self.phone = phone
        self.products = products or []

class DemoProduct:
    def __init__(self, id, name, category, barcode, supplier, quantity, reorder_level, cost_price, selling_price, image_path=None):
        self.id = id
        self.name = name
        self.category = category
        self.barcode = barcode
        self.supplier = supplier
        self.quantity = quantity
        self.reorder_level = reorder_level
        self.cost_price = cost_price
        self.selling_price = selling_price
        self.image_path = image_path
    def is_low_stock(self):
        return self.quantity <= self.reorder_level

# ---- Demo datasets ----
demo_categories = [
    DemoCategory('Dairy'), DemoCategory('Bakery'), DemoCategory('Beverages'),
    DemoCategory('Snacks'), DemoCategory('Fruits'), DemoCategory('Vegetables')
]

demo_suppliers = [
    DemoSupplier(1, 'Fresh Farms Co.', 'Alice Green', 'alice@freshfarms.com', '+1 555-1010'),
    DemoSupplier(2, 'Baker Bros.', 'Bob Baker', 'bob@bakerbros.com', '+1 555-2020'),
]

demo_products = [
    DemoProduct(1, 'Milk 1L', demo_categories[0], '1234567890123', demo_suppliers[0], 12, 10, 0.80, 1.20),
    DemoProduct(2, 'Whole Wheat Bread', demo_categories[1], '2345678901234', demo_suppliers[1], 5, 8, 1.00, 1.60),
    DemoProduct(3, 'Orange Juice', demo_categories[2], '3456789012345', demo_suppliers[0], 0, 6, 1.20, 2.10),
    DemoProduct(4, 'Potato Chips', demo_categories[3], '4567890123456', demo_suppliers[1], 18, 5, 0.70, 1.30),
]

# link products to suppliers for counts
demo_suppliers[0].products = [p for p in demo_products if p.supplier == demo_suppliers[0]]
demo_suppliers[1].products = [p for p in demo_products if p.supplier == demo_suppliers[1]]

# ---- Blueprints matching template endpoint names ----
dashboard_bp = Blueprint('dashboard', __name__, url_prefix='/dashboard')
product_bp = Blueprint('product', __name__, url_prefix='/products')
supplier_bp = Blueprint('supplier', __name__, url_prefix='/suppliers')
order_bp = Blueprint('order', __name__, url_prefix='/orders')
report_bp = Blueprint('report', __name__, url_prefix='/reports')
auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

# Home redirects to dashboard
@app.route('/')
def home():
    return redirect(url_for('dashboard.index'))

# ---- Dashboard routes ----
@dashboard_bp.route('/')
def index():
    product_count = len(demo_products)
    low_stock_count = len([p for p in demo_products if p.is_low_stock()])
    order_count = 45  # demo number
    supplier_count = len(demo_suppliers)

    recent_orders = [
        {'id': 101, 'customer_name': 'John Doe', 'total_amount': 23.50, 'order_date': datetime.now()},
        {'id': 102, 'customer_name': 'Jane Smith', 'total_amount': 18.20, 'order_date': datetime.now()},
    ]

    low_stock_products = [p for p in demo_products if p.is_low_stock()][:5]

    dates = ['2023-10-01', '2023-10-02', '2023-10-03', '2023-10-04', '2023-10-05']
    sales = [1200, 1350, 980, 1420, 1560]

    ai_insights = [
        "Top selling products: Milk 1L, Whole Wheat Bread, Orange Juice",
        f"Alert: {low_stock_count} products are low in stock and need reordering",
        "Seasonal insight: Prepare for holiday season by stocking up on festive items"
    ]

    return render_template(
        'dashboard/index.html',
        product_count=product_count,
        low_stock_count=low_stock_count,
        order_count=order_count,
        supplier_count=supplier_count,
        recent_orders=recent_orders,
        low_stock_products=low_stock_products,
        dates=dates,
        sales=sales,
        ai_insights=ai_insights
    )

@dashboard_bp.route('/ai')
def ai_predictions():
    seasonal_trends = [
        {'season': 'Winter', 'trend': 'Hot beverages rise', 'recommendation': 'Stock coffee, tea, soups'},
        {'season': 'Summer', 'trend': 'Cold drinks surge', 'recommendation': 'Boost juices, soft drinks, ice cream'}
    ]
    product_predictions = {
        'Milk 1L': {
            '2023-10-06': 14, '2023-10-07': 16, '2023-10-08': 12, '2023-10-09': 18, '2023-10-10': 17
        },
        'Whole Wheat Bread': {
            '2023-10-06': 8, '2023-10-07': 9, '2023-10-08': 7, '2023-10-09': 10, '2023-10-10': 11
        }
    }
    return render_template('dashboard/ai_predictions.html', seasonal_trends=seasonal_trends, product_predictions=product_predictions)

# ---- Product routes ----
@product_bp.route('/')
def index():
    return render_template('product/index.html', products=demo_products, categories=demo_categories)

@product_bp.route('/new')
def new():
    return redirect(url_for('product.index'))

@product_bp.route('/<int:id>/edit')
def edit(id):
    return redirect(url_for('product.index'))

@product_bp.route('/<int:id>/delete', methods=['POST'])
def delete(id):
    return redirect(url_for('product.index'))

@product_bp.route('/categories')
def categories():
    return redirect(url_for('product.index'))

# ---- Supplier routes ----
@supplier_bp.route('/', endpoint='index')
def index_supplier():
    return render_template('supplier/index.html', suppliers=demo_suppliers)

@supplier_bp.route('/new')
def new_supplier():
    return redirect(url_for('supplier.index'))

@supplier_bp.route('/orders')
def orders_supplier():
    return redirect(url_for('supplier.index'))

@supplier_bp.route('/<int:id>')
def view(id):
    return redirect(url_for('supplier.index'))

@supplier_bp.route('/<int:id>/edit')
def edit_supplier(id):
    return redirect(url_for('supplier.index'))

@supplier_bp.route('/<int:id>/delete', methods=['POST'])
def delete_supplier(id):
    return redirect(url_for('supplier.index'))

# ---- Orders & Reports (placeholders) ----
@order_bp.route('/', endpoint='index')
def index_order():
    return render_template('layout.html')

@report_bp.route('/', endpoint='index')
def index_report():
    return render_template('layout.html')

# ---- Auth placeholders ----
@auth_bp.route('/profile')
def profile():
    return redirect(url_for('dashboard.index'))

@auth_bp.route('/logout')
def logout():
    return redirect(url_for('dashboard.index'))

@auth_bp.route('/users')
def users():
    return redirect(url_for('dashboard.index'))

@auth_bp.route('/user-logs')
def user_logs():
    return redirect(url_for('dashboard.index'))

# ---- Register blueprints ----
app.register_blueprint(dashboard_bp)
app.register_blueprint(product_bp)
app.register_blueprint(supplier_bp)
app.register_blueprint(order_bp)
app.register_blueprint(report_bp)
app.register_blueprint(auth_bp)

if __name__ == '__main__':
    app.run(debug=True)