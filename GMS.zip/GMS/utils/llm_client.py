import os
import json
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class LLMClient:
    """Thin client for calling an LLM provider with graceful fallback.

    Uses OpenAI API if `OPENAI_API_KEY` is present. Otherwise, returns a heuristic reply.
    """

    def __init__(self):
        self.api_key = os.getenv('OPENAI_API_KEY')
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')

    def chat(self, prompt: str, system: Optional[str] = None) -> str:
        # If no API key, provide a local heuristic response
        if not self.api_key:
            logger.warning('No OPENAI_API_KEY found; using offline heuristic response')
            return self._offline_response(prompt)

        try:
            # Try using requests, fallback to urllib if not available
            try:
                import requests
                headers = {
                    'Authorization': f'Bearer {self.api_key}',
                    'Content-Type': 'application/json'
                }
                messages = []
                if system:
                    messages.append({"role": "system", "content": system})
                messages.append({"role": "user", "content": prompt})
                payload = {"model": self.model, "messages": messages, "temperature": 0.2}
                resp = requests.post('https://api.openai.com/v1/chat/completions', headers=headers, json=payload, timeout=15)
                resp.raise_for_status()
                data = resp.json()
                return (data.get('choices') or [{}])[0].get('message', {}).get('content', '').strip() or 'No content returned.'
            except ImportError:
                import urllib.request
                req = urllib.request.Request(
                    url='https://api.openai.com/v1/chat/completions',
                    data=json.dumps({
                        "model": self.model,
                        "messages": ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": prompt}],
                        "temperature": 0.2
                    }).encode('utf-8'),
                    headers={'Authorization': f'Bearer {self.api_key}', 'Content-Type': 'application/json'}
                )
                with urllib.request.urlopen(req, timeout=15) as f:
                    data = json.loads(f.read().decode('utf-8'))
                    return (data.get('choices') or [{}])[0].get('message', {}).get('content', '').strip() or 'No content returned.'
        except Exception as e:
            logger.error(f"LLM API error: {e}")
            return self._offline_response(prompt)

    def _offline_response(self, prompt: str) -> str:
        # Simple rule-based fallback that tries to be helpful
        lower = prompt.lower()
        if 'error' in lower or 'issue' in lower or 'problem' in lower:
            return (
                "I can help troubleshoot. Please share the exact error message,"
                " the steps that led to it, and what changed recently. In the meantime:"
                "\n- Check server logs (terminal output) for tracebacks"
                "\n- Verify environment variables in .env"
                "\n- Confirm database connectivity and credentials"
                "\n- Try reproducing the issue and list steps"
            )
        if 'how to' in lower or 'help' in lower:
            return (
                "Here are general help topics: sales reports, low stock alerts,"
                " predictions, seasonal trends, suppliers, and orders. Ask me"
                " something like: 'Show last 7 days sales' or 'Create task: Fix low stock for Milk'."
            )
        return (
            "I'm operating in offline mode. I can still answer domain-specific"
            " questions (sales, stock, suppliers) and create or list tasks."
            " If you set OPENAI_API_KEY in your .env, I can answer general questions too."
        )