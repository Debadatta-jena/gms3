"""
Offline AI Chatbot Engine
Integrates NLP processing, ML models, and chat memory for intelligent responses
"""

import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
from .offline_nlp_engine import OfflineNLPEngine
from .offline_ml_models import OfflineMLModels
from .chat_memory import ChatMemory

logger = logging.getLogger(__name__)

class OfflineChatbot:
    """Main offline chatbot engine"""
    
    def __init__(self, db_session):
        self.db = db_session
        # Pass the database session to the NLP engine for optional DB-backed entity resolution
        self.nlp_engine = OfflineNLPEngine(db_session)
        self.ml_models = OfflineMLModels(db_session)
        self.memory = ChatMemory()
        
        # Initialize greeting message
        self.greeting_messages = [
            "Hello! I'm your AI assistant for the Grocery Management System. How can I help you today?",
            "Hi there! I'm here to help with inventory, sales, suppliers, and business insights. What would you like to know?",
            "Welcome! I can assist with stock levels, sales analysis, predictions, and task management. How may I help?"
        ]
        
        # Domain knowledge
        self.domain_responses = {
            'greeting': self.greeting_messages,
            'capabilities': [
                "I can help you with:",
                "• Stock levels and inventory management",
                "• Sales analysis and reports", 
                "• Supplier information and performance",
                "• Business predictions and insights",
                "• Task creation and management",
                "• Low stock alerts and recommendations"
            ],
            'out_of_domain': [
                "I'm specialized in grocery store management. I can help with inventory, sales, suppliers, and business insights.",
                "Sorry, I can only assist with questions related to your grocery store operations.",
                "I focus on inventory management, sales analysis, and business operations. How can I help with your store?"
            ]
        }
    
    def process_message(self, user_message: str, user_id: str = None) -> Dict:
        """Process user message and generate response"""
        try:
            # Parse user input
            # Use the NLP engine to parse user input (intent + entities)
            parsed_input = self.nlp_engine.parse_query(user_message)
            intent = parsed_input['intent']
            entities = parsed_input['entities']
            confidence = parsed_input['confidence']
            
            # Get conversation context
            context = self.memory.get_context(user_message)
            
            # Generate response based on intent
            response_data = self._generate_response(intent, entities, user_message, context)
            
            # Add memory and context info
            response_data['context'] = self.memory.get_context_for_response(user_message)
            response_data['is_follow_up'] = self.memory.is_follow_up_question(user_message)
            
            # Save to memory
            self.memory.add_message(
                user_message=user_message,
                bot_response=response_data['response'],
                intent=intent,
                entities=entities
            )
            
            return response_data
            
        except Exception as e:
            logger.error(f"Error processing message: {e}")
            return self._generate_error_response()
    
    def _generate_response(self, intent: str, entities: Dict, user_message: str, context: Dict) -> Dict:
        """Generate response based on intent and entities"""
        
        if intent == 'greeting':
            return self._handle_greeting(context)
        
        elif intent == 'stock_query':
            return self._handle_stock_query(entities)
        
        elif intent == 'sales_query':
            return self._handle_sales_query(entities)
        
        elif intent == 'supplier_query':
            return self._handle_supplier_query(entities)
        
        elif intent == 'prediction_query':
            return self._handle_prediction_query(entities, user_message)
        
        elif intent == 'task_management':
            return self._handle_task_management(entities, user_message)
        
        elif intent == 'low_stock_alert':
            return self._handle_low_stock_alert()
        
        elif intent == 'help' or intent == 'capabilities':
            return self._handle_help_request()
        
        elif intent == 'analytics':
            return self._handle_analytics_request(entities)
        
        elif intent == 'general_info':
            return self._handle_general_info(user_message, context)
        
        # Treat generic queries as general info to avoid out-of-domain fallback
        elif intent == 'general_query':
            return self._handle_general_info(user_message, context)
        
        else:
            return self._handle_out_of_domain()
    
    def _handle_greeting(self, context: Dict) -> Dict:
        """Handle greeting messages"""
        import random
        
        # Check if user has been active recently
        session_info = context.get('session_summary', {})
        
        if session_info.get('message_count', 0) > 0:
            response = f"Welcome back! We've exchanged {session_info['message_count']} messages in this session. How can I continue helping you?"
        else:
            response = random.choice(self.greeting_messages)
        
        return {
            'response': response,
            'intent': 'greeting',
            'data': None,
            'suggestions': [
                "Show current stock levels",
                "Sales report for today",
                "Low stock alerts",
                "Predict next week sales"
            ]
        }
    
    def _handle_stock_query(self, entities: Dict) -> Dict:
        """Handle stock-related queries"""
        try:
            from models.product import Product
            from models.product import Category
            
            # Support keys from NLP engine ('product' or 'product_name')
            product_name = entities.get('product_name') or entities.get('product')
            category = entities.get('category')
            
            if product_name:
                # Specific product query
                product = Product.query.filter(
                    Product.name.ilike(f'%{product_name}%')
                ).first()
                
                if product:
                    response = f"📦 **{product.name}**\n"
                    response += f"• Current Stock: {product.quantity} units\n"
                    response += f"• Category: {product.category.name if product.category else 'N/A'}\n"
                    response += f"• Price: ${product.selling_price:.2f}\n"
                    
                    low_threshold = product.reorder_level or 10
                    if product.quantity <= low_threshold:
                        response += f"⚠️ **Low Stock Alert!** Consider restocking soon."
                    
                    return {
                        'response': response,
                        'intent': 'stock_query',
                        'data': {
                            'product_id': product.id,
                            'stock_level': product.quantity,
                            'low_stock': product.quantity <= low_threshold
                        }
                    }
                else:
                    return {
                        'response': f"❌ Product '{product_name}' not found in inventory. Please check the spelling or try a different search term.",
                        'intent': 'stock_query',
                        'data': None
                    }
            
            elif category:
                # Category-based query
                products = Product.query.join(Category).filter(
                    Category.name.ilike(f'%{category}%')
                ).limit(10).all()
                
                if products:
                    response = f"📋 **Stock levels for {category.title()} category:**\n\n"
                    total_items = 0
                    low_stock_items = 0
                    
                    for product in products:
                        threshold = product.reorder_level or 10
                        stock_status = "✅" if product.quantity > threshold else "⚠️"
                        response += f"{stock_status} {product.name}: {product.quantity} units\n"
                        total_items += product.quantity
                        if product.quantity <= threshold:
                            low_stock_items += 1
                    
                    response += f"\n📊 **Summary:** {len(products)} products, {total_items} total units"
                    if low_stock_items > 0:
                        response += f", {low_stock_items} items need restocking"
                    
                    return {
                        'response': response,
                        'intent': 'stock_query',
                        'data': {
                            'category': category,
                            'total_products': len(products),
                            'low_stock_count': low_stock_items
                        }
                    }
                else:
                    return {
                        'response': f"❌ No products found in '{category}' category.",
                        'intent': 'stock_query',
                        'data': None
                    }
            
            else:
                # General stock overview
                products = Product.query.limit(20).all()
                total_products = Product.query.count()
                # Low stock defined by quantity <= reorder_level
                low_stock_products = Product.query.filter(Product.quantity <= Product.reorder_level).count()
                
                response = f"📊 **Inventory Overview:**\n\n"
                response += f"• Total Products: {total_products}\n"
                response += f"• Low Stock Items: {low_stock_products}\n"
                response += f"• Stock Status: {'⚠️ Attention Needed' if low_stock_products > 5 else '✅ Good'}\n\n"
                
                if low_stock_products > 0:
                    response += "**Items needing attention:**\n"
                    low_stock_items = Product.query.filter(Product.quantity <= Product.reorder_level).limit(5).all()
                    for item in low_stock_items:
                        response += f"• {item.name}: {item.quantity} units\n"
                
                return {
                    'response': response,
                    'intent': 'stock_query',
                    'data': {
                        'total_products': total_products,
                        'low_stock_count': low_stock_products
                    }
                }
                
        except Exception as e:
            logger.error(f"Error in stock query: {e}")
            return {
                'response': "❌ Sorry, I encountered an error while checking stock levels. Please try again.",
                'intent': 'stock_query',
                'data': None
            }
    
    def _handle_sales_query(self, entities: Dict) -> Dict:
        """Handle sales-related queries"""
        try:
            from models.order import Order
            from datetime import datetime, timedelta
            
            time_period = entities.get('time_period', 'today')
            
            # Calculate date range
            end_date = datetime.now().date()
            
            if time_period in ['today', 'daily']:
                start_date = end_date
                period_name = "Today"
            elif time_period in ['week', 'weekly', '7 days']:
                start_date = end_date - timedelta(days=7)
                period_name = "Last 7 Days"
            elif time_period in ['month', 'monthly', '30 days']:
                start_date = end_date - timedelta(days=30)
                period_name = "Last 30 Days"
            else:
                start_date = end_date - timedelta(days=7)
                period_name = "Last 7 Days"
            
            # Get sales data
            orders = Order.query.filter(
                Order.order_date >= start_date,
                Order.order_date <= end_date
            ).all()
            
            if orders:
                total_sales = sum(order.total_amount for order in orders)
                total_orders = len(orders)
                avg_order_value = total_sales / total_orders if total_orders > 0 else 0
                
                response = f"💰 **Sales Report - {period_name}:**\n\n"
                response += f"• Total Sales: ${total_sales:.2f}\n"
                response += f"• Total Orders: {total_orders}\n"
                response += f"• Average Order Value: ${avg_order_value:.2f}\n"
                
                # Daily breakdown for weekly/monthly reports
                if time_period in ['week', 'weekly', 'month', 'monthly']:
                    daily_sales = {}
                    for order in orders:
                        date_str = order.order_date.strftime('%Y-%m-%d')
                        daily_sales[date_str] = daily_sales.get(date_str, 0) + order.total_amount
                    
                    if daily_sales:
                        response += f"\n📈 **Daily Breakdown:**\n"
                        for date, amount in sorted(daily_sales.items())[-7:]:  # Last 7 days
                            response += f"• {date}: ${amount:.2f}\n"
                
                return {
                    'response': response,
                    'intent': 'sales_query',
                    'data': {
                        'total_sales': float(total_sales),
                        'total_orders': total_orders,
                        'avg_order_value': float(avg_order_value),
                        'period': period_name
                    }
                }
            else:
                return {
                    'response': f"📊 No sales data found for {period_name.lower()}.",
                    'intent': 'sales_query',
                    'data': None
                }
                
        except Exception as e:
            logger.error(f"Error in sales query: {e}")
            return {
                'response': "❌ Sorry, I encountered an error while retrieving sales data. Please try again.",
                'intent': 'sales_query',
                'data': None
            }
    
    def _handle_supplier_query(self, entities: Dict) -> Dict:
        """Handle supplier-related queries"""
        try:
            from models.supplier import Supplier
            
            # Support keys from NLP engine ('supplier' or 'supplier_name')
            supplier_name = entities.get('supplier_name') or entities.get('supplier')
            
            if supplier_name:
                # Specific supplier query
                supplier = Supplier.query.filter(
                    Supplier.name.ilike(f'%{supplier_name}%')
                ).first()
                
                if supplier:
                    response = f"🏢 **{supplier.name}**\n\n"
                    response += f"• Contact Person: {supplier.contact_person}\n"
                    response += f"• Phone: {supplier.phone}\n"
                    response += f"• Email: {supplier.email}\n"
                    response += f"• Address: {supplier.address}\n"
                    
                    return {
                        'response': response,
                        'intent': 'supplier_query',
                        'data': {
                            'supplier_id': supplier.id,
                            'name': supplier.name,
                            'contact': supplier.contact_person
                        }
                    }
                else:
                    return {
                        'response': f"❌ Supplier '{supplier_name}' not found. Please check the name or try a different search term.",
                        'intent': 'supplier_query',
                        'data': None
                    }
            else:
                # General supplier overview
                suppliers = Supplier.query.all()
                
                if suppliers:
                    response = f"🏢 **Supplier Directory ({len(suppliers)} suppliers):**\n\n"
                    
                    for supplier in suppliers[:10]:  # Show first 10
                        response += f"• **{supplier.name}**\n"
                        response += f"  Contact: {supplier.contact_person} - {supplier.phone}\n\n"
                    
                    if len(suppliers) > 10:
                        response += f"... and {len(suppliers) - 10} more suppliers.\n"
                    
                    return {
                        'response': response,
                        'intent': 'supplier_query',
                        'data': {
                            'total_suppliers': len(suppliers)
                        }
                    }
                else:
                    return {
                        'response': "📋 No suppliers found in the system.",
                        'intent': 'supplier_query',
                        'data': None
                    }
                    
        except Exception as e:
            logger.error(f"Error in supplier query: {e}")
            return {
                'response': "❌ Sorry, I encountered an error while retrieving supplier information. Please try again.",
                'intent': 'supplier_query',
                'data': None
            }
    
    def _handle_prediction_query(self, entities: Dict, user_message: str) -> Dict:
        """Handle prediction and forecasting queries"""
        try:
            query_type = entities.get('prediction_type', 'sales')
            
            if 'sales' in user_message.lower() or 'revenue' in user_message.lower():
                # Sales prediction
                prediction_result = self.ml_models.predict_sales(days_ahead=7)
                
                if prediction_result['status'] == 'success':
                    predictions = prediction_result['predictions']
                    confidence = prediction_result['confidence']
                    
                    response = f"📈 **Sales Forecast - Next 7 Days:**\n\n"
                    
                    total_predicted = 0
                    for pred in predictions:
                        response += f"• {pred['date']}: ${pred['predicted_sales']:.2f}\n"
                        total_predicted += pred['predicted_sales']
                    
                    response += f"\n💡 **Summary:**\n"
                    response += f"• Total Predicted Sales: ${total_predicted:.2f}\n"
                    response += f"• Average Daily Sales: ${total_predicted/7:.2f}\n"
                    response += f"• Confidence Level: {confidence*100:.0f}%\n"
                    response += f"• Model Used: {prediction_result['model_used']}"
                    
                    return {
                        'response': response,
                        'intent': 'prediction_query',
                        'data': prediction_result
                    }
            
            elif 'seasonal' in user_message.lower() or 'pattern' in user_message.lower():
                # Seasonal analysis
                seasonal_result = self.ml_models.analyze_seasonal_patterns()
                
                if seasonal_result['status'] == 'success':
                    response = f"📊 **Seasonal Demand Analysis:**\n\n"
                    
                    peak_season = seasonal_result['peak_season']
                    low_season = seasonal_result['low_season']
                    
                    response += f"🔥 **Peak Season:** {peak_season['month']} (${peak_season['sales']:.2f})\n"
                    response += f"❄️ **Low Season:** {low_season['month']} (${low_season['sales']:.2f})\n\n"
                    
                    response += "📈 **Monthly Trends:**\n"
                    for trend in seasonal_result['seasonal_trends'][:6]:  # Show first 6 months
                        emoji = "🔥" if trend['trend'] == 'High Demand' else "❄️" if trend['trend'] == 'Low Demand' else "📊"
                        response += f"{emoji} {trend['month']}: {trend['trend']} (${trend['avg_sales']:.2f})\n"
                    
                    return {
                        'response': response,
                        'intent': 'prediction_query',
                        'data': seasonal_result
                    }
            
            elif 'demand' in user_message.lower() or 'product' in user_message.lower():
                # Product demand prediction
                category = entities.get('category')
                demand_result = self.ml_models.predict_product_demand(category)
                
                if demand_result['status'] == 'success':
                    products = demand_result['high_demand_products']
                    
                    response = f"🎯 **High Demand Products Forecast:**\n\n"
                    
                    for i, product in enumerate(products[:5], 1):
                        response += f"{i}. **{product['product_name']}**\n"
                        response += f"   • Demand Score: {product['demand_score']}/100\n"
                        response += f"   • Predicted Sales: ${product['predicted_sales']:.2f}\n"
                        response += f"   • Recommendation: {product['recommendation']}\n\n"
                    
                    return {
                        'response': response,
                        'intent': 'prediction_query',
                        'data': demand_result
                    }
            
            else:
                # General prediction capabilities
                return {
                    'response': "🔮 **AI Prediction Capabilities:**\n\n• Sales forecasting (next 7 days)\n• Seasonal demand patterns\n• Product demand analysis\n• Supplier performance trends\n\nTry asking: 'Predict sales for next week' or 'Show seasonal patterns'",
                    'intent': 'prediction_query',
                    'data': None
                }
                
        except Exception as e:
            logger.error(f"Error in prediction query: {e}")
            return {
                'response': "❌ Sorry, I encountered an error while generating predictions. Please try again.",
                'intent': 'prediction_query',
                'data': None
            }
    
    def _handle_task_management(self, entities: Dict, user_message: str) -> Dict:
        """Handle task management operations"""
        try:
            from models.chat import ChatTask
            
            action = entities.get('action', 'list')
            task_description = entities.get('task_description')
            
            if action == 'create' and task_description:
                # Create new task
                new_task = ChatTask(
                    title=task_description,
                    status='open',
                    created_at=datetime.now(),
                    updated_at=datetime.now()
                )
                self.db.session.add(new_task)
                self.db.session.commit()
                
                return {
                    'response': f"✅ Task created successfully!\n\n📝 **Task:** {task_description}\n🕐 **Created:** {datetime.now().strftime('%Y-%m-%d %H:%M')}\n📊 **Status:** Open",
                    'intent': 'task_management',
                    'data': {'task_id': new_task.id, 'action': 'create'}
                }
            
            elif action == 'list':
                # List tasks
                tasks = ChatTask.query.filter_by(status='open').limit(10).all()
                
                if tasks:
                    response = f"📋 **Pending Tasks ({len(tasks)}):**\n\n"
                    
                    for i, task in enumerate(tasks, 1):
                        response += f"{i}. {task.title}\n"
                        response += f"   🕐 Created: {task.created_at.strftime('%Y-%m-%d %H:%M')}\n\n"
                    
                    return {
                        'response': response,
                        'intent': 'task_management',
                        'data': {'tasks': [{'id': t.id, 'title': t.title} for t in tasks]}
                    }
                else:
                    return {
                        'response': "📋 No pending tasks found. You're all caught up! 🎉",
                        'intent': 'task_management',
                        'data': {'tasks': []}
                    }
            
            elif action == 'complete':
                # Complete task (by ID or description)
                task_id = entities.get('task_id')
                
                if task_id:
                    task = ChatTask.query.get(task_id)
                    if task:
                        task.status = 'done'
                        task.updated_at = datetime.now()
                        self.db.session.commit()
                        
                        return {
                            'response': f"✅ Task completed!\n\n📝 **Task:** {task.title}\n🎉 **Completed:** {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                            'intent': 'task_management',
                            'data': {'task_id': task.id, 'action': 'complete'}
                        }
                
                return {
                    'response': "❌ Task not found. Please provide a valid task ID or description.",
                    'intent': 'task_management',
                    'data': None
                }
            
            else:
                return {
                    'response': "📝 **Task Management Commands:**\n\n• 'Create task: [description]' - Add new task\n• 'List tasks' - Show pending tasks\n• 'Complete task [ID]' - Mark task as done\n\nExample: 'Create task: Order more milk supplies'",
                    'intent': 'task_management',
                    'data': None
                }
                
        except Exception as e:
            logger.error(f"Error in task management: {e}")
            return {
                'response': "❌ Sorry, I encountered an error while managing tasks. Please try again.",
                'intent': 'task_management',
                'data': None
            }
    
    def _handle_low_stock_alert(self) -> Dict:
        """Handle low stock alerts"""
        try:
            from models.product import Product
            
            low_stock_products = Product.query.filter(Product.quantity <= Product.reorder_level).all()
            
            if low_stock_products:
                response = f"⚠️ **Low Stock Alert ({len(low_stock_products)} items):**\n\n"
                
                for product in low_stock_products[:10]:  # Show first 10
                    urgency = "🔴 URGENT" if product.quantity < max(3, product.reorder_level or 3) else "🟡 LOW"
                    response += f"{urgency} **{product.name}**\n"
                    response += f"   • Current Stock: {product.quantity} units\n"
                    response += f"   • Category: {product.category.name if product.category else 'N/A'}\n"
                    response += f"   • Price: ${product.selling_price:.2f}\n\n"
                
                if len(low_stock_products) > 10:
                    response += f"... and {len(low_stock_products) - 10} more items need attention.\n"
                
                response += "\n💡 **Recommendation:** Consider placing orders for these items soon."
                
                return {
                    'response': response,
                    'intent': 'low_stock_alert',
                    'data': {
                        'low_stock_count': len(low_stock_products),
                        'urgent_items': len([p for p in low_stock_products if p.quantity < max(3, p.reorder_level or 3)])
                    }
                }
            else:
                return {
                    'response': "✅ **All Good!** No low stock alerts at the moment. All products have adequate inventory levels.",
                    'intent': 'low_stock_alert',
                    'data': {'low_stock_count': 0}
                }
                
        except Exception as e:
            logger.error(f"Error in low stock alert: {e}")
            return {
                'response': "❌ Sorry, I encountered an error while checking stock levels. Please try again.",
                'intent': 'low_stock_alert',
                'data': None
            }
    
    def _handle_help_request(self) -> Dict:
        """Handle help and capabilities requests"""
        capabilities = self.domain_responses['capabilities']
        response = "\n".join(capabilities)
        
        response += "\n\n🎯 **Example Questions:**\n"
        response += "• 'Show stock for milk products'\n"
        response += "• 'Sales report for last week'\n"
        response += "• 'Predict sales for next week'\n"
        response += "• 'Create task: Order more supplies'\n"
        response += "• 'Low stock alerts'\n"
        response += "• 'Supplier contact for ABC Foods'"
        
        return {
            'response': response,
            'intent': 'help',
            'data': None,
            'suggestions': [
                "Show current stock",
                "Sales report",
                "Low stock alerts",
                "Create a task"
            ]
        }
    
    def _handle_analytics_request(self, entities: Dict) -> Dict:
        """Handle analytics and insights requests"""
        try:
            # Get supplier performance analysis
            supplier_analysis = self.ml_models.analyze_supplier_performance()
            
            response = "📊 **Business Analytics Dashboard:**\n\n"
            
            if supplier_analysis['status'] == 'success':
                top_supplier = supplier_analysis.get('top_performer')
                if top_supplier:
                    response += f"🏆 **Top Supplier:** {top_supplier['supplier_name']} ({top_supplier['performance_score']}/100)\n"
                
                needs_attention = supplier_analysis.get('needs_attention', [])
                if needs_attention:
                    response += f"⚠️ **Suppliers Needing Attention:** {len(needs_attention)}\n"
            
            response += "\n💡 **Available Analytics:**\n"
            response += "• Sales forecasting and trends\n"
            response += "• Seasonal demand patterns\n"
            response += "• Product performance analysis\n"
            response += "• Supplier performance metrics\n"
            response += "• Inventory optimization insights"
            
            return {
                'response': response,
                'intent': 'analytics',
                'data': supplier_analysis
            }
            
        except Exception as e:
            logger.error(f"Error in analytics request: {e}")
            return {
                'response': "❌ Sorry, I encountered an error while generating analytics. Please try again.",
                'intent': 'analytics',
                'data': None
            }
    
    def _handle_general_info(self, user_message: str, context: Dict) -> Dict:
        """Handle general information requests"""
        # Check if it's a follow-up question
        if context.get('current_topic'):
            response = f"I understand you're asking about {context['current_topic']}. Could you be more specific? "
            response += "I can help with stock levels, sales data, predictions, or supplier information."
        else:
            response = "I'd be happy to help! I specialize in grocery store management. "
            response += "I can assist with inventory, sales analysis, predictions, and business insights. "
            response += "What specific information are you looking for?"
        
        return {
            'response': response,
            'intent': 'general_info',
            'data': None,
            'suggestions': [
                "Check stock levels",
                "View sales report",
                "Get predictions",
                "Manage tasks"
            ]
        }
    
    def _handle_out_of_domain(self) -> Dict:
        """Handle out-of-domain queries"""
        import random
        response = random.choice(self.domain_responses['out_of_domain'])
        
        return {
            'response': response,
            'intent': 'out_of_domain',
            'data': None,
            'suggestions': [
                "Show inventory status",
                "Sales analysis",
                "Business predictions",
                "Task management"
            ]
        }
    
    def _generate_error_response(self) -> Dict:
        """Generate error response"""
        return {
            'response': "❌ I apologize, but I encountered an unexpected error. Please try rephrasing your question or contact support if the issue persists.",
            'intent': 'error',
            'data': None,
            'suggestions': [
                "Try a simpler question",
                "Check system status",
                "Contact support"
            ]
        }
    
    def get_conversation_stats(self) -> Dict:
        """Get conversation statistics"""
        return self.memory.get_conversation_stats()
    
    def clear_conversation(self):
        """Clear current conversation session"""
        self.memory.clear_session()
    
    def get_system_status(self) -> Dict:
        """Get chatbot system status"""
        try:
            from models.product import Product
            from models.order import Order
            from models.supplier import Supplier
            
            return {
                'status': 'online',
                'components': {
                    'nlp_engine': 'active',
                    'ml_models': 'active',
                    'chat_memory': 'active',
                    'database': 'connected'
                },
                'data_summary': {
                    'total_products': Product.query.count(),
                    'total_orders': Order.query.count(),
                    'total_suppliers': Supplier.query.count()
                },
                'conversation_stats': self.get_conversation_stats()
            }
        except Exception as e:
            logger.error(f"Error getting system status: {e}")
            return {
                'status': 'error',
                'error': str(e)
            }