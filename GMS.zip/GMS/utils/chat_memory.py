"""
Chat Memory System for Context-Aware Conversations
Maintains conversation history and context without external dependencies
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import logging

logger = logging.getLogger(__name__)

class ChatMemory:
    """Context-aware chat memory system"""
    
    def __init__(self, memory_file: str = 'chat_memory.json', max_context_length: int = 10):
        self.memory_file = memory_file
        self.max_context_length = max_context_length
        self.current_session = []
        self.conversation_history = []
        self.user_preferences = {}
        self.context_keywords = []
        
        # Load existing memory
        self._load_memory()
    
    def add_message(self, user_message: str, bot_response: str, intent: str = None, entities: Dict = None):
        """Add a new message exchange to memory"""
        timestamp = datetime.now().isoformat()
        
        message_entry = {
            'timestamp': timestamp,
            'user_message': user_message,
            'bot_response': bot_response,
            'intent': intent,
            'entities': entities or {},
            'session_id': self._get_current_session_id()
        }
        
        # Add to current session
        self.current_session.append(message_entry)
        
        # Add to conversation history
        self.conversation_history.append(message_entry)
        
        # Update context keywords
        self._update_context_keywords(user_message, intent, entities)
        
        # Maintain memory size
        self._maintain_memory_size()
        
        # Save to file
        self._save_memory()
    
    def get_context(self, query: str = None) -> Dict:
        """Get relevant context for current conversation"""
        context = {
            'recent_messages': self._get_recent_messages(),
            'current_topic': self._get_current_topic(),
            'user_preferences': self.user_preferences,
            'relevant_history': self._get_relevant_history(query) if query else [],
            'session_summary': self._get_session_summary()
        }
        
        return context
    
    def get_conversation_summary(self) -> str:
        """Get a summary of the current conversation"""
        if not self.current_session:
            return "No conversation history in current session."
        
        topics = []
        intents = []
        
        for message in self.current_session[-5:]:  # Last 5 messages
            if message.get('intent'):
                intents.append(message['intent'])
            
            # Extract topics from user messages
            user_msg = message['user_message'].lower()
            if 'stock' in user_msg or 'inventory' in user_msg:
                topics.append('inventory')
            elif 'sales' in user_msg or 'revenue' in user_msg:
                topics.append('sales')
            elif 'supplier' in user_msg:
                topics.append('suppliers')
            elif 'task' in user_msg:
                topics.append('tasks')
        
        # Create summary
        unique_topics = list(set(topics))
        unique_intents = list(set(intents))
        
        summary_parts = []
        
        if unique_topics:
            summary_parts.append(f"Discussed topics: {', '.join(unique_topics)}")
        
        if unique_intents:
            summary_parts.append(f"Recent queries: {', '.join(unique_intents)}")
        
        summary_parts.append(f"Messages in session: {len(self.current_session)}")
        
        return ". ".join(summary_parts) + "."
    
    def update_user_preference(self, key: str, value: Any):
        """Update user preferences"""
        self.user_preferences[key] = value
        self._save_memory()
    
    def get_user_preference(self, key: str, default: Any = None) -> Any:
        """Get user preference"""
        return self.user_preferences.get(key, default)
    
    def clear_session(self):
        """Clear current session but keep history"""
        self.current_session = []
        self.context_keywords = []
        self._save_memory()
    
    def search_history(self, query: str, limit: int = 5) -> List[Dict]:
        """Search conversation history for relevant messages"""
        query_lower = query.lower()
        relevant_messages = []
        
        for message in reversed(self.conversation_history):
            user_msg = message['user_message'].lower()
            bot_response = message['bot_response'].lower()
            
            # Check if query terms appear in message
            if any(term in user_msg or term in bot_response for term in query_lower.split()):
                relevant_messages.append(message)
                
                if len(relevant_messages) >= limit:
                    break
        
        return relevant_messages
    
    def get_frequent_queries(self, limit: int = 5) -> List[Dict]:
        """Get most frequent query types"""
        intent_counts = {}
        
        for message in self.conversation_history:
            intent = message.get('intent')
            if intent:
                intent_counts[intent] = intent_counts.get(intent, 0) + 1
        
        # Sort by frequency
        sorted_intents = sorted(intent_counts.items(), key=lambda x: x[1], reverse=True)
        
        return [{'intent': intent, 'count': count} for intent, count in sorted_intents[:limit]]
    
    def _get_current_session_id(self) -> str:
        """Generate session ID based on current date"""
        return datetime.now().strftime('%Y%m%d_%H')
    
    def _get_recent_messages(self, count: int = 3) -> List[Dict]:
        """Get recent messages from current session"""
        return self.current_session[-count:] if self.current_session else []
    
    def _get_current_topic(self) -> Optional[str]:
        """Determine current conversation topic"""
        if not self.current_session:
            return None
        
        recent_intents = [msg.get('intent') for msg in self.current_session[-3:] if msg.get('intent')]
        
        if not recent_intents:
            return None
        
        # Find most common recent intent
        intent_counts = {}
        for intent in recent_intents:
            intent_counts[intent] = intent_counts.get(intent, 0) + 1
        
        return max(intent_counts, key=intent_counts.get)
    
    def _get_relevant_history(self, query: str) -> List[Dict]:
        """Get relevant historical messages based on query"""
        if not query:
            return []
        
        return self.search_history(query, limit=3)
    
    def _get_session_summary(self) -> Dict:
        """Get summary of current session"""
        if not self.current_session:
            return {'message_count': 0, 'duration': 0, 'topics': []}
        
        start_time = datetime.fromisoformat(self.current_session[0]['timestamp'])
        end_time = datetime.fromisoformat(self.current_session[-1]['timestamp'])
        duration_minutes = (end_time - start_time).total_seconds() / 60
        
        # Extract topics
        topics = []
        for message in self.current_session:
            if message.get('intent'):
                topics.append(message['intent'])
        
        unique_topics = list(set(topics))
        
        return {
            'message_count': len(self.current_session),
            'duration_minutes': round(duration_minutes, 1),
            'topics': unique_topics,
            'start_time': start_time.strftime('%H:%M'),
            'last_activity': end_time.strftime('%H:%M')
        }
    
    def _update_context_keywords(self, user_message: str, intent: str, entities: Dict):
        """Update context keywords based on conversation"""
        # Add intent as keyword
        if intent and intent not in self.context_keywords:
            self.context_keywords.append(intent)
        
        # Add entity values as keywords
        if entities:
            for entity_type, entity_value in entities.items():
                if isinstance(entity_value, str) and entity_value not in self.context_keywords:
                    self.context_keywords.append(entity_value.lower())
        
        # Extract important words from user message
        important_words = self._extract_important_words(user_message)
        for word in important_words:
            if word not in self.context_keywords:
                self.context_keywords.append(word)
        
        # Keep only recent keywords
        if len(self.context_keywords) > 20:
            self.context_keywords = self.context_keywords[-20:]
    
    def _extract_important_words(self, text: str) -> List[str]:
        """Extract important words from text"""
        # Simple keyword extraction
        important_words = []
        text_lower = text.lower()
        
        # Business-related keywords
        business_keywords = [
            'stock', 'inventory', 'sales', 'revenue', 'profit', 'supplier', 'customer',
            'product', 'category', 'price', 'order', 'delivery', 'payment', 'report',
            'analysis', 'prediction', 'forecast', 'trend', 'demand', 'supply'
        ]
        
        for keyword in business_keywords:
            if keyword in text_lower:
                important_words.append(keyword)
        
        return important_words
    
    def _maintain_memory_size(self):
        """Maintain memory size within limits"""
        # Keep only recent conversation history
        max_history = 100
        if len(self.conversation_history) > max_history:
            self.conversation_history = self.conversation_history[-max_history:]
        
        # Keep only recent session messages
        if len(self.current_session) > self.max_context_length:
            self.current_session = self.current_session[-self.max_context_length:]
    
    def _load_memory(self):
        """Load memory from file"""
        try:
            if os.path.exists(self.memory_file):
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    
                    self.conversation_history = data.get('conversation_history', [])
                    self.user_preferences = data.get('user_preferences', {})
                    
                    # Load current session if it's from today
                    current_session_id = self._get_current_session_id()
                    recent_messages = [
                        msg for msg in self.conversation_history
                        if msg.get('session_id') == current_session_id
                    ]
                    
                    # Only load session if it's from the last 2 hours
                    cutoff_time = datetime.now() - timedelta(hours=2)
                    self.current_session = [
                        msg for msg in recent_messages
                        if datetime.fromisoformat(msg['timestamp']) > cutoff_time
                    ]
                    
        except Exception as e:
            logger.error(f"Error loading chat memory: {e}")
            self.conversation_history = []
            self.user_preferences = {}
            self.current_session = []
    
    def _save_memory(self):
        """Save memory to file"""
        try:
            data = {
                'conversation_history': self.conversation_history,
                'user_preferences': self.user_preferences,
                'last_updated': datetime.now().isoformat()
            }
            
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            logger.error(f"Error saving chat memory: {e}")
    
    def get_context_for_response(self, user_query: str) -> str:
        """Get formatted context string for response generation"""
        context = self.get_context(user_query)
        
        context_parts = []
        
        # Add recent conversation context
        if context['recent_messages']:
            recent_topics = [msg.get('intent', 'general') for msg in context['recent_messages']]
            context_parts.append(f"Recent topics: {', '.join(set(recent_topics))}")
        
        # Add current topic
        if context['current_topic']:
            context_parts.append(f"Current focus: {context['current_topic']}")
        
        # Add relevant history
        if context['relevant_history']:
            context_parts.append("User has previously asked about similar topics")
        
        # Add session info
        session_info = context['session_summary']
        if session_info['message_count'] > 0:
            context_parts.append(f"Session: {session_info['message_count']} messages, {session_info['duration_minutes']} min")
        
        return ". ".join(context_parts) if context_parts else "New conversation"
    
    def is_follow_up_question(self, user_query: str) -> bool:
        """Check if current query is a follow-up to previous conversation"""
        if not self.current_session:
            return False
        
        # Check for follow-up indicators
        follow_up_words = ['also', 'and', 'what about', 'how about', 'additionally', 'furthermore']
        query_lower = user_query.lower()
        
        if any(word in query_lower for word in follow_up_words):
            return True
        
        # Check if query relates to recent topics
        recent_keywords = []
        for msg in self.current_session[-2:]:
            if msg.get('entities'):
                recent_keywords.extend(msg['entities'].values())
        
        return any(keyword.lower() in query_lower for keyword in recent_keywords if isinstance(keyword, str))
    
    def get_conversation_stats(self) -> Dict:
        """Get conversation statistics"""
        total_messages = len(self.conversation_history)
        session_messages = len(self.current_session)
        
        # Calculate average session length
        sessions = {}
        for msg in self.conversation_history:
            session_id = msg.get('session_id', 'unknown')
            sessions[session_id] = sessions.get(session_id, 0) + 1
        
        avg_session_length = sum(sessions.values()) / len(sessions) if sessions else 0
        
        # Get most common intents
        frequent_queries = self.get_frequent_queries(3)
        
        return {
            'total_messages': total_messages,
            'current_session_messages': session_messages,
            'average_session_length': round(avg_session_length, 1),
            'total_sessions': len(sessions),
            'frequent_queries': frequent_queries,
            'user_preferences_count': len(self.user_preferences)
        }