"""
Offline Natural Language Processing Engine for Chatbot
Handles query parsing, intent recognition, and entity extraction without external APIs
"""

import re
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from fuzzywuzzy import fuzz, process
import nltk
from textblob import TextBlob
import logging

# Download required NLTK data (run once)
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords', quiet=True)

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

logger = logging.getLogger(__name__)

class OfflineNLPEngine:
    """Offline NLP engine for parsing user queries and extracting intents"""
    
    def __init__(self, db_session):
        self.db = db_session
        self.stop_words = set(stopwords.words('english'))
        
        # Intent patterns and keywords
        self.intent_patterns = {
            'stock_query': [
                'stock', 'inventory', 'quantity', 'available', 'how many', 'count',
                'items', 'products', 'goods', 'supplies', 'inventory status', 'show inventory', 'stock status'
            ],
            'sales_query': [
                'sales', 'sold', 'revenue', 'earnings', 'profit', 'income',
                'daily', 'weekly', 'monthly', 'today', 'yesterday', 'last week'
            ],
            'supplier_query': [
                'supplier', 'vendor', 'provider', 'contact', 'phone', 'email',
                'address', 'orders', 'pending', 'delivery'
            ],
            'low_stock_alert': [
                'low stock', 'running low', 'reorder', 'shortage', 'empty',
                'out of stock', 'need to order', 'alert'
            ],
            'product_info': [
                'price', 'cost', 'category', 'expiry', 'expire', 'details',
                'information', 'about', 'description'
            ],
            'prediction_query': [
                'predict', 'predictions', 'forecast', 'future', 'next week', 'next month',
                'trend', 'pattern', 'will sell', 'demand', 'seasonal', 'business predictions'
            ],
            'task_management': [
                'create task', 'add task', 'list tasks', 'show tasks',
                'complete task', 'finish task', 'delete task', 'todo', 'task management', 'tasks'
            ],
            'help': [
                'help', 'options', 'capabilities', 'what can you do'
            ],
            'report_generation': [
                'report', 'generate', 'create report', 'summary',
                'analysis', 'statistics', 'overview'
            ]
        }
        
        # Entity patterns
        self.entity_patterns = {
            'product_name': r'\b(?:milk|bread|juice|rice|sugar|flour|oil|tea|coffee|cheese|butter|eggs|chicken|beef|fish|apple|banana|orange|tomato|potato|onion)\b',
            'time_period': r'\b(?:today|yesterday|last week|this week|last month|this month|daily|weekly|monthly)\b',
            'number': r'\b\d+\b',
            'supplier_name': r'\b(?:supplier|vendor)\s+([A-Za-z\s]+)\b'
        }
        
        # Context memory
        self.context_memory = []
        self.max_context_length = 5
        
    def parse_query(self, user_input: str) -> Dict:
        """Parse user input and extract intent, entities, and context"""
        user_input = user_input.lower().strip()
        
        # Store in context
        self.context_memory.append({
            'query': user_input,
            'timestamp': datetime.now().isoformat()
        })
        
        # Keep only recent context
        if len(self.context_memory) > self.max_context_length:
            self.context_memory.pop(0)
        
        # Extract intent
        intent = self._extract_intent(user_input)
        
        # Extract entities
        entities = self._extract_entities(user_input)
        
        # Get context
        context = self._get_context()
        
        return {
            'intent': intent,
            'entities': entities,
            'context': context,
            'original_query': user_input,
            'confidence': self._calculate_confidence(intent, entities)
        }
    
    def _extract_intent(self, text: str) -> str:
        """Extract the primary intent from user text"""
        text_blob = TextBlob(text)
        tokens = [word.lower() for word in text_blob.words if word.lower() not in self.stop_words]
        
        intent_scores = {}
        
        for intent, keywords in self.intent_patterns.items():
            score = 0
            for keyword in keywords:
                # Exact match
                if keyword in text:
                    score += 10
                
                # Fuzzy match for individual words
                for token in tokens:
                    fuzzy_score = fuzz.ratio(keyword, token)
                    if fuzzy_score > 80:
                        score += fuzzy_score / 10
            
            intent_scores[intent] = score
        
        # Return intent with highest score
        if intent_scores:
            best_intent = max(intent_scores, key=intent_scores.get)
            if intent_scores[best_intent] > 5:  # Minimum confidence threshold
                return best_intent
        
        return 'general_query'
    
    def _extract_entities(self, text: str) -> Dict:
        """Extract entities like product names, time periods, numbers"""
        entities = {}
        
        # Extract product names using fuzzy matching with database
        product_names = self._get_product_names()
        if product_names:
            best_match = process.extractOne(text, product_names, scorer=fuzz.partial_ratio)
            if best_match and best_match[1] > 60:  # 60% similarity threshold
                entities['product'] = best_match[0]
                entities['product_name'] = best_match[0]
        
        # Extract time periods
        time_match = re.search(self.entity_patterns['time_period'], text)
        if time_match:
            entities['time_period'] = time_match.group()
        
        # Extract numbers
        numbers = re.findall(self.entity_patterns['number'], text)
        if numbers:
            entities['numbers'] = [int(n) for n in numbers]
        
        # Extract supplier names
        supplier_match = re.search(self.entity_patterns['supplier_name'], text)
        if supplier_match:
            supplier = supplier_match.group(1).strip()
            entities['supplier'] = supplier
            entities['supplier_name'] = supplier

        # Extract category names from DB for entity matching
        try:
            from models.product import Category
            categories = [c.name.lower() for c in Category.query.all()]
            if categories:
                cat_match = process.extractOne(text, categories, scorer=fuzz.partial_ratio)
                if cat_match and cat_match[1] > 70:
                    entities['category'] = cat_match[0]
        except Exception as e:
            logger.error(f"Error fetching categories: {e}")
        
        return entities
    
    def _get_product_names(self) -> List[str]:
        """Get all product names from database for entity matching"""
        try:
            from models.product import Product
            products = Product.query.all()
            return [product.name.lower() for product in products]
        except Exception as e:
            logger.error(f"Error fetching product names: {e}")
            return []
    
    def _get_context(self) -> List[Dict]:
        """Get recent conversation context"""
        return self.context_memory[-3:] if len(self.context_memory) > 1 else []
    
    def _calculate_confidence(self, intent: str, entities: Dict) -> float:
        """Calculate confidence score for the parsed query"""
        base_confidence = 0.7 if intent != 'general_query' else 0.3
        
        # Boost confidence if entities are found
        if entities:
            base_confidence += 0.2
        
        # Boost confidence if product is identified
        if 'product' in entities:
            base_confidence += 0.1
        
        return min(base_confidence, 1.0)
    
    def generate_sql_query(self, parsed_query: Dict) -> Optional[str]:
        """Generate SQL query based on parsed intent and entities"""
        intent = parsed_query['intent']
        entities = parsed_query['entities']
        
        try:
            if intent == 'stock_query':
                if 'product' in entities:
                    return f"SELECT name, quantity, reorder_level FROM products WHERE LOWER(name) LIKE '%{entities['product']}%'"
                else:
                    return "SELECT name, quantity, reorder_level FROM products ORDER BY quantity DESC LIMIT 10"
            
            elif intent == 'sales_query':
                time_filter = self._get_time_filter(entities.get('time_period', 'today'))
                return f"SELECT DATE(order_date) as date, SUM(total_amount) as total_sales FROM orders WHERE {time_filter} GROUP BY DATE(order_date) ORDER BY date DESC"
            
            elif intent == 'low_stock_alert':
                return "SELECT name, quantity, reorder_level FROM products WHERE quantity <= reorder_level ORDER BY quantity ASC"
            
            elif intent == 'supplier_query':
                if 'supplier' in entities:
                    return f"SELECT * FROM suppliers WHERE LOWER(name) LIKE '%{entities['supplier']}%'"
                else:
                    return "SELECT name, contact_person, phone, email FROM suppliers ORDER BY name"
            
            elif intent == 'product_info':
                if 'product' in entities:
                    return f"SELECT * FROM products WHERE LOWER(name) LIKE '%{entities['product']}%'"
                else:
                    return "SELECT name, price, category, expiry_date FROM products ORDER BY name LIMIT 10"
            
        except Exception as e:
            logger.error(f"Error generating SQL query: {e}")
        
        return None
    
    def _get_time_filter(self, time_period: str) -> str:
        """Generate SQL time filter based on time period"""
        today = datetime.now().date()
        
        if time_period in ['today']:
            return f"DATE(order_date) = '{today}'"
        elif time_period in ['yesterday']:
            yesterday = today - timedelta(days=1)
            return f"DATE(order_date) = '{yesterday}'"
        elif time_period in ['last week', 'this week']:
            week_start = today - timedelta(days=7)
            return f"DATE(order_date) >= '{week_start}'"
        elif time_period in ['last month', 'this month']:
            month_start = today - timedelta(days=30)
            return f"DATE(order_date) >= '{month_start}'"
        else:
            return f"DATE(order_date) = '{today}'"
    
    def clear_context(self):
        """Clear conversation context"""
        self.context_memory = []