import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, accuracy_score
import joblib
import os
from datetime import datetime, timedelta
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AIEngine:
    def __init__(self, db):
        self.db = db
        self.models_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ai_models')
        os.makedirs(self.models_dir, exist_ok=True)
        
        # Model file paths
        self.sales_prediction_model_path = os.path.join(self.models_dir, 'sales_prediction_model.joblib')
        self.customer_interest_model_path = os.path.join(self.models_dir, 'customer_interest_model.joblib')
        
        # Initialize models
        self.sales_prediction_model = None
        self.customer_interest_model = None
        
        # Load models if they exist
        self._load_models()
    
    def _load_models(self):
        """Load trained models if they exist"""
        try:
            if os.path.exists(self.sales_prediction_model_path):
                self.sales_prediction_model = joblib.load(self.sales_prediction_model_path)
                logger.info("Sales prediction model loaded successfully")
            
            if os.path.exists(self.customer_interest_model_path):
                self.customer_interest_model = joblib.load(self.customer_interest_model_path)
                logger.info("Customer interest model loaded successfully")
        except Exception as e:
            logger.error(f"Error loading models: {str(e)}")
    
    def prepare_sales_data(self):
        """Prepare sales data for training the sales prediction model"""
        from models.order import Order, OrderItem
        from models.product import Product, Category
        
        try:
            # Get all order items with their related orders and products
            order_items = self.db.session.query(
                OrderItem, Order, Product, Category
            ).join(
                Order, OrderItem.order_id == Order.id
            ).join(
                Product, OrderItem.product_id == Product.id
            ).join(
                Category, Product.category_id == Category.id
            ).all()
            
            if not order_items:
                logger.warning("No order data available for training")
                return None
            
            # Prepare data
            data = []
            for item, order, product, category in order_items:
                # Extract day of week, month, etc. from order date
                order_date = order.order_date
                
                data.append({
                    'product_id': product.id,
                    'category_id': category.id,
                    'category_name': category.name,
                    'day_of_week': order_date.weekday(),
                    'day_of_month': order_date.day,
                    'month': order_date.month,
                    'year': order_date.year,
                    'quantity': item.quantity,
                    'unit_price': item.unit_price,
                    'subtotal': item.subtotal
                })
            
            return pd.DataFrame(data)
        except Exception as e:
            logger.error(f"Error preparing sales data: {str(e)}")
            return None
    
    def prepare_customer_interest_data(self):
        """Prepare customer interest data for training the customer interest model"""
        from models.order import Order, OrderItem
        from models.product import Product, Category
        
        try:
            # Get all orders with customer information
            orders = self.db.session.query(Order).all()
            
            if not orders:
                logger.warning("No order data available for training")
                return None
            
            # Prepare data
            data = []
            for order in orders:
                customer_key = f"{order.customer_name}_{order.customer_email}_{order.customer_phone}"
                
                for item in order.items:
                    product = self.db.session.query(Product).get(item.product_id)
                    if product:
                        category = self.db.session.query(Category).get(product.category_id) if product.category_id else None
                        
                        data.append({
                            'customer_key': customer_key,
                            'product_id': product.id,
                            'category_id': category.id if category else None,
                            'category_name': category.name if category else 'Unknown',
                            'quantity': item.quantity,
                            'purchase_date': order.order_date,
                            'day_of_week': order.order_date.weekday(),
                            'month': order.order_date.month
                        })
            
            return pd.DataFrame(data)
        except Exception as e:
            logger.error(f"Error preparing customer interest data: {str(e)}")
            return None
    
    def train_sales_prediction_model(self):
        """Train the sales prediction model"""
        try:
            # Prepare data
            df = self.prepare_sales_data()
            if df is None or df.empty:
                logger.warning("No data available for training sales prediction model")
                return False
            
            # Features and target
            X = df[['product_id', 'category_id', 'day_of_week', 'day_of_month', 'month', 'year']]
            y = df['quantity']
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Define preprocessing
            numeric_features = ['day_of_week', 'day_of_month', 'month', 'year']
            categorical_features = ['product_id', 'category_id']
            
            numeric_transformer = StandardScaler()
            categorical_transformer = OneHotEncoder(handle_unknown='ignore')
            
            preprocessor = ColumnTransformer(
                transformers=[
                    ('num', numeric_transformer, numeric_features),
                    ('cat', categorical_transformer, categorical_features)
                ])
            
            # Create and train the model
            model = Pipeline(steps=[
                ('preprocessor', preprocessor),
                ('regressor', RandomForestRegressor(n_estimators=100, random_state=42))
            ])
            
            model.fit(X_train, y_train)
            
            # Evaluate the model
            y_pred = model.predict(X_test)
            mse = mean_squared_error(y_test, y_pred)
            rmse = np.sqrt(mse)
            logger.info(f"Sales prediction model RMSE: {rmse}")
            
            # Save the model
            joblib.dump(model, self.sales_prediction_model_path)
            self.sales_prediction_model = model
            
            return True
        except Exception as e:
            logger.error(f"Error training sales prediction model: {str(e)}")
            return False
    
    def train_customer_interest_model(self):
        """Train the customer interest model"""
        try:
            # Prepare data
            df = self.prepare_customer_interest_data()
            if df is None or df.empty:
                logger.warning("No data available for training customer interest model")
                return False
            
            # Group by customer and category to get purchase frequency
            customer_category = df.groupby(['customer_key', 'category_id']).size().reset_index(name='purchase_count')
            
            # Create a binary target: 1 if customer purchased from category more than once, 0 otherwise
            customer_category['interested'] = (customer_category['purchase_count'] > 1).astype(int)
            
            # Features and target
            X = customer_category[['customer_key', 'category_id']]
            y = customer_category['interested']
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Define preprocessing
            categorical_features = ['customer_key', 'category_id']
            categorical_transformer = OneHotEncoder(handle_unknown='ignore')
            
            preprocessor = ColumnTransformer(
                transformers=[
                    ('cat', categorical_transformer, categorical_features)
                ])
            
            # Create and train the model
            model = Pipeline(steps=[
                ('preprocessor', preprocessor),
                ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
            ])
            
            model.fit(X_train, y_train)
            
            # Evaluate the model
            y_pred = model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            logger.info(f"Customer interest model accuracy: {accuracy}")
            
            # Save the model
            joblib.dump(model, self.customer_interest_model_path)
            self.customer_interest_model = model
            
            return True
        except Exception as e:
            logger.error(f"Error training customer interest model: {str(e)}")
            return False
    
    def predict_sales(self, product_id, days_ahead=7):
        """Predict sales for a specific product for the next X days"""
        try:
            if self.sales_prediction_model is None:
                logger.warning("Sales prediction model not trained yet")
                return None
            
            # Get product and category information
            from models.product import Product
            product = self.db.session.query(Product).get(product_id)
            if not product:
                logger.warning(f"Product with ID {product_id} not found")
                return None
            
            category_id = product.category_id
            
            # Generate predictions for each day
            predictions = []
            today = datetime.now()
            
            for i in range(1, days_ahead + 1):
                future_date = today + timedelta(days=i)
                
                # Prepare input data
                input_data = pd.DataFrame({
                    'product_id': [product_id],
                    'category_id': [category_id],
                    'day_of_week': [future_date.weekday()],
                    'day_of_month': [future_date.day],
                    'month': [future_date.month],
                    'year': [future_date.year]
                })
                
                # Make prediction
                predicted_quantity = max(0, round(self.sales_prediction_model.predict(input_data)[0]))
                
                predictions.append({
                    'date': future_date.strftime('%Y-%m-%d'),
                    'predicted_quantity': predicted_quantity
                })
            
            return predictions
        except Exception as e:
            logger.error(f"Error predicting sales: {str(e)}")
            return None
    
    def get_customer_interests(self, customer_key):
        """Get predicted categories of interest for a customer"""
        try:
            if self.customer_interest_model is None:
                logger.warning("Customer interest model not trained yet")
                return None
            
            # Get all categories
            from models.product import Category
            categories = self.db.session.query(Category).all()
            
            if not categories:
                logger.warning("No categories found")
                return None
            
            # Prepare input data for all categories
            input_data = pd.DataFrame({
                'customer_key': [customer_key] * len(categories),
                'category_id': [category.id for category in categories]
            })
            
            # Make predictions
            predictions = self.customer_interest_model.predict_proba(input_data)
            
            # Get probability of interest (class 1)
            interest_probs = predictions[:, 1] if predictions.shape[1] > 1 else predictions
            
            # Combine with category information
            results = []
            for i, category in enumerate(categories):
                results.append({
                    'category_id': category.id,
                    'category_name': category.name,
                    'interest_probability': float(interest_probs[i])
                })
            
            # Sort by interest probability (descending)
            results.sort(key=lambda x: x['interest_probability'], reverse=True)
            
            return results
        except Exception as e:
            logger.error(f"Error getting customer interests: {str(e)}")
            return None
    
    def get_seasonal_trends(self):
        """Identify seasonal trends in product categories"""
        try:
            # Prepare data
            df = self.prepare_sales_data()
            if df is None or df.empty:
                # Fallback: provide sensible default seasonal trends when no sales data exists
                logger.warning("No data available for seasonal trend analysis; returning default seasonal suggestions")
                default_trends = {
                    'January': {
                        'category': 'Soups & Hot Beverages',
                        'recommendation': 'Promote tea, coffee, cocoa, and instant soups for cold weather.'
                    },
                    'February': {
                        'category': 'Confectionery & Gifts',
                        'recommendation': 'Feature chocolates, sweets, and gift bundles around Valentine’s Day.'
                    },
                    'March': {
                        'category': 'Fresh Produce & Greens',
                        'recommendation': 'Highlight spring greens, berries, and lighter meal ingredients.'
                    },
                    'April': {
                        'category': 'Bakery & Brunch',
                        'recommendation': 'Stock baking staples and brunch items for Easter and spring gatherings.'
                    },
                    'May': {
                        'category': 'BBQ & Grilling',
                        'recommendation': 'Push meats, marinades, sauces, buns, and charcoal as weather warms.'
                    },
                    'June': {
                        'category': 'Cold Drinks & Ice Cream',
                        'recommendation': 'Promote soft drinks, juices, water, and ice cream for summer heat.'
                    },
                    'July': {
                        'category': 'Picnic & BBQ Essentials',
                        'recommendation': 'Condiments, snacks, paper goods, and grilling supplies for outdoor events.'
                    },
                    'August': {
                        'category': 'Back-to-School Essentials',
                        'recommendation': 'Feature lunchbox snacks, cereals, dairy, and quick breakfast items.'
                    },
                    'September': {
                        'category': 'Baking & Pantry Staples',
                        'recommendation': 'Promote flour, sugar, spices, canned goods, and comfort meal bases.'
                    },
                    'October': {
                        'category': 'Comfort Foods & Halloween',
                        'recommendation': 'Pumpkin products, candies, warm meals, and baking mixes.'
                    },
                    'November': {
                        'category': 'Holiday Baking & Frozen Sides',
                        'recommendation': 'Stock pie crusts, baking staples, frozen sides, and broths.'
                    },
                    'December': {
                        'category': 'Holiday Entertaining & Beverages',
                        'recommendation': 'Sparkling drinks, party platters, premium snacks, and giftable treats.'
                    }
                }
                return default_trends
            
            # Group by month and category
            monthly_category_sales = df.groupby(['month', 'category_name'])['quantity'].sum().reset_index()
            
            # Pivot to get categories as columns
            pivot_table = monthly_category_sales.pivot(index='month', columns='category_name', values='quantity')
            
            # Fill missing values with 0
            pivot_table = pivot_table.fillna(0)
            
            # Get top category for each month
            top_categories = {}
            for month in range(1, 13):
                if month in pivot_table.index:
                    month_data = pivot_table.loc[month]
                    top_category = month_data.idxmax()
                    top_categories[month] = {
                        'category': top_category,
                        'quantity': month_data[top_category]
                    }
            
            # Convert month numbers to names
            month_names = {
                1: 'January', 2: 'February', 3: 'March', 4: 'April',
                5: 'May', 6: 'June', 7: 'July', 8: 'August',
                9: 'September', 10: 'October', 11: 'November', 12: 'December'
            }
            
            formatted_trends = {}
            for month_num, data in top_categories.items():
                # Add a simple recommendation note along with the detected top category
                formatted_trends[month_names[month_num]] = {
                    'category': data.get('category'),
                    'quantity': data.get('quantity'),
                    'recommendation': f"Consider promoting {data.get('category')} in {month_names[month_num]}."
                }
            
            return formatted_trends
        except Exception as e:
            logger.error(f"Error analyzing seasonal trends: {str(e)}")
            return None
    
    def generate_insights(self):
        """Generate AI insights for the dashboard"""
        try:
            insights = []
            
            # Get low stock products
            from models.product import Product
            low_stock = self.db.session.query(Product).filter(Product.quantity <= Product.reorder_level).all()
            if low_stock:
                insights.append(f"You have {len(low_stock)} products with low stock that need attention.")
            
            # Get expiring products
            thirty_days_from_now = datetime.now() + timedelta(days=30)
            expiring_soon = self.db.session.query(Product).filter(
                Product.expiry_date <= thirty_days_from_now,
                Product.expiry_date >= datetime.now()
            ).all()
            if expiring_soon:
                insights.append(f"{len(expiring_soon)} products will expire in the next 30 days.")
            
            # Get seasonal trends
            seasonal_trends = self.get_seasonal_trends()
            if seasonal_trends:
                current_month = datetime.now().strftime('%B')
                if current_month in seasonal_trends:
                    insights.append(f"Trending category this month: {seasonal_trends[current_month]['category']}.")
                
                next_month = (datetime.now() + timedelta(days=30)).strftime('%B')
                if next_month in seasonal_trends:
                    insights.append(f"Prepare for next month: {seasonal_trends[next_month]['category']} typically sells well in {next_month}.")
            
            # Get top selling products
            from models.order import OrderItem
            from sqlalchemy import func
            
            top_products = self.db.session.query(
                Product.name, func.sum(OrderItem.quantity).label('total_quantity')
            ).join(
                OrderItem, Product.id == OrderItem.product_id
            ).group_by(
                Product.id
            ).order_by(
                func.sum(OrderItem.quantity).desc()
            ).limit(3).all()
            
            if top_products:
                top_product_names = [p[0] for p in top_products]
                insights.append(f"Top selling products: {', '.join(top_product_names)}.")
            
            return insights
        except Exception as e:
            logger.error(f"Error generating insights: {str(e)}")
            return ["AI insights currently unavailable. Please check back later."]