import os
import sys
import logging
import schedule
import time
from datetime import datetime

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs', 'ai_trainer.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def train_models():
    """Train all AI models"""
    try:
        logger.info("Starting scheduled AI model training")
        
        # Import here to avoid circular imports
        from app import create_app, db
        from utils.ai_engine import AIEngine
        
        # Create app context
        app = create_app()
        with app.app_context():
            # Initialize AI engine
            ai_engine = AIEngine(db)
            
            # Train sales prediction model
            logger.info("Training sales prediction model")
            sales_result = ai_engine.train_sales_prediction_model()
            if sales_result:
                logger.info("Sales prediction model trained successfully")
            else:
                logger.warning("Failed to train sales prediction model")
            
            # Train customer interest model
            logger.info("Training customer interest model")
            interest_result = ai_engine.train_customer_interest_model()
            if interest_result:
                logger.info("Customer interest model trained successfully")
            else:
                logger.warning("Failed to train customer interest model")
            
        logger.info("Scheduled AI model training completed")
        
        # Log training timestamp
        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs', 'last_training.txt'), 'w') as f:
            f.write(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            
    except Exception as e:
        logger.error(f"Error during scheduled model training: {str(e)}")

def main():
    """Main function to schedule and run AI model training"""
    try:
        # Create logs directory if it doesn't exist
        logs_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
        os.makedirs(logs_dir, exist_ok=True)
        
        logger.info("AI Trainer started")
        
        # Schedule training to run daily at midnight
        schedule.every().day.at("00:00").do(train_models)
        
        # Also run once at startup
        logger.info("Running initial model training")
        train_models()
        
        # Keep the script running
        while True:
            schedule.run_pending()
            time.sleep(60)  # Check every minute
            
    except KeyboardInterrupt:
        logger.info("AI Trainer stopped by user")
    except Exception as e:
        logger.error(f"Error in AI Trainer: {str(e)}")

if __name__ == "__main__":
    main()