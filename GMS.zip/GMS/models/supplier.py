from datetime import datetime
from app import db

class Supplier(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    contact_person = db.Column(db.String(100))
    email = db.Column(db.String(120))
    phone = db.Column(db.String(20), nullable=False)
    address = db.Column(db.String(200))
    reliability_rating = db.Column(db.Float, default=5.0)  # 1-5 scale
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)
    
    # Relationships
    products = db.relationship('Product', backref='supplier', lazy=True)
    orders = db.relationship('SupplierOrder', backref='supplier', lazy=True)
    
    def __repr__(self):
        return f"Supplier('{self.name}', '{self.phone}')"

class SupplierOrder(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey('supplier.id'), nullable=False)
    order_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    expected_delivery = db.Column(db.Date)
    actual_delivery = db.Column(db.Date)
    status = db.Column(db.String(20), default='pending')  # pending, delivered, cancelled
    total_amount = db.Column(db.Float, nullable=False)
    payment_status = db.Column(db.String(20), default='unpaid')  # unpaid, partial, paid
    notes = db.Column(db.Text)
    
    # Relationships
    items = db.relationship('SupplierOrderItem', backref='order', lazy=True)
    
    def __repr__(self):
        return f"SupplierOrder('{self.id}', '{self.supplier_id}', '{self.status}')"

class SupplierOrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('supplier_order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Float, nullable=False)
    
    def __repr__(self):
        return f"SupplierOrderItem('{self.order_id}', '{self.product_id}', '{self.quantity}')"