import os, sys
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, os.pardir))
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)

from app import app, db
from utils.offline_chatbot import OfflineChatbot

def test_messages():
    chatbot = OfflineChatbot(db)
    tests = [
        "Show inventory status",
        "Business predictions",
        "Task management",
        "Sales report for today",
        "Low stock alerts",
        "Create task: Order more milk",
    ]
    for msg in tests:
        resp = chatbot.process_message(msg)
        print("===", msg, "===")
        print(resp.get('response'))
        print("intent:", resp.get('intent'), "data:", resp.get('data'))
        print()

if __name__ == '__main__':
    with app.app_context():
        test_messages()