from app import app, db
from models.user import User
from models.product import Category, Product
from models.supplier import Supplier, SupplierOrder, SupplierOrderItem
from models.order import Order, OrderItem
from models.chat import ChatMessage, ChatTask
import os

# Create a context for commands
@app.shell_context_processor
def make_shell_context():
    return {
        'db': db, 
        'User': User, 
        'Category': Category, 
        'Product': Product,
        'Supplier': Supplier,
        'SupplierOrder': SupplierOrder,
        'SupplierOrderItem': SupplierOrderItem,
        'Order': Order,
        'OrderItem': OrderItem,
        'ChatMessage': ChatMessage,
        'ChatTask': ChatTask
    }

if __name__ == '__main__':
    # Ensure database tables exist and seed a demo admin
    with app.app_context():
        db.create_all()
        # Seed a demo admin user if none exists
        if not User.query.filter_by(username='admin').first():
            admin = User(username='admin', email='admin@example.com', role='admin')
            admin.set_password('admin')
            db.session.add(admin)
            db.session.commit()
    # Run the application
    app.run(debug=True)