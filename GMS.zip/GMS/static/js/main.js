// Minimal JS for presentation mode
document.addEventListener('DOMContentLoaded', function () {
  console.log('Presentation mode assets loaded');
  const splash = document.getElementById('splash');
  if (splash) {
    // Show splash briefly, then fade it out
    const DISPLAY_MS = 1600; // how long to show splash
    setTimeout(() => {
      splash.classList.add('fade-out');
      // Remove from DOM after transition for accessibility and click-through
      setTimeout(() => splash.remove(), 700);
    }, DISPLAY_MS);
  }
});