import argparse
from datetime import datetime, date
from typing import Optional

from app import app, db
from models.product import Product, Category
from models.supplier import Supplier
from models.chat import ChatTask


def ensure_tables():
    """Ensure DB tables exist."""
    db.create_all()


def get_category_by_name(name: str) -> Optional[Category]:
    return Category.query.filter(Category.name.ilike(name)).first()


def get_supplier_by_name(name: str) -> Optional[Supplier]:
    return Supplier.query.filter(Supplier.name.ilike(name)).first()


def cmd_seed(args):
    """Seed basic categories, suppliers, and sample products."""
    # Categories
    categories = [
        ('Dairy', 'Milk, cheese, butter, etc.'),
        ('Bakery', 'Bread, cakes, pastries, etc.'),
        ('Beverages', 'Soft drinks, juices, water, etc.'),
        ('Snacks', 'Chips, cookies, nuts, etc.'),
        ('Fruits', 'Fresh fruits'),
        ('Vegetables', 'Fresh vegetables'),
    ]
    for name, desc in categories:
        if not get_category_by_name(name):
            db.session.add(Category(name=name, description=desc))

    # Suppliers
    suppliers = [
        ('Dairy Farm Inc.', 'John Doe', 'john@dairyfarm.com', '123-456-7890', '123 Milk St, Dairy Town'),
        ('Fresh Bakery Co.', 'Jane Smith', 'jane@freshbakery.com', '234-567-8901', '456 Bread Ave, Baker City'),
        ('Beverage World', 'Bob Johnson', 'bob@beverageworld.com', '345-678-9012', '789 Drink Blvd, Soda Springs'),
    ]
    for name, contact, email, phone, addr in suppliers:
        if not get_supplier_by_name(name):
            db.session.add(Supplier(name=name, contact_person=contact, email=email, phone=phone, address=addr))

    db.session.commit()

    # Sample products
    dairy = get_category_by_name('Dairy')
    bakery = get_category_by_name('Bakery')
    beverages = get_category_by_name('Beverages')

    s1 = get_supplier_by_name('Dairy Farm Inc.')
    s2 = get_supplier_by_name('Fresh Bakery Co.')
    s3 = get_supplier_by_name('Beverage World')

    samples = [
        ('Milk 1L', '1234567890123', dairy, s1, 0.80, 1.20, 50, 10, date.today()),
        ('Bread', '2345678901234', bakery, s2, 1.00, 1.50, 30, 5, date.today()),
        ('Cola 500ml', '3456789012345', beverages, s3, 0.50, 1.00, 100, 20, None),
    ]
    for name, barcode, cat, sup, cost, price, qty, reorder, exp in samples:
        if not Product.query.filter_by(barcode=barcode).first() and cat and sup:
            db.session.add(Product(
                name=name,
                barcode=barcode,
                category_id=cat.id,
                supplier_id=sup.id,
                purchase_price=cost,
                selling_price=price,
                quantity=qty,
                reorder_level=reorder,
                expiry_date=exp,
            ))

    db.session.commit()
    print('Seed completed: categories, suppliers, and sample products ensured.')


def cmd_add_category(args):
    if get_category_by_name(args.name):
        print(f"Category '{args.name}' already exists.")
        return
    db.session.add(Category(name=args.name, description=args.description))
    db.session.commit()
    print(f"Category '{args.name}' added.")


def cmd_list_categories(args):
    cats = Category.query.order_by(Category.name.asc()).all()
    for c in cats:
        print(f"[{c.id}] {c.name} - {c.description or ''}")
    print(f"Total categories: {len(cats)}")


def cmd_add_supplier(args):
    if get_supplier_by_name(args.name):
        print(f"Supplier '{args.name}' already exists.")
        return
    sup = Supplier(
        name=args.name,
        contact_person=args.contact_person,
        email=args.email,
        phone=args.phone,
        address=args.address,
    )
    db.session.add(sup)
    db.session.commit()
    print(f"Supplier '{args.name}' added with id {sup.id}.")


def cmd_list_suppliers(args):
    sups = Supplier.query.order_by(Supplier.name.asc()).all()
    for s in sups:
        print(f"[{s.id}] {s.name} - {s.phone} - {s.contact_person or ''}")
    print(f"Total suppliers: {len(sups)}")


def cmd_add_product(args):
    cat = get_category_by_name(args.category)
    sup = get_supplier_by_name(args.supplier)
    if not cat:
        print(f"Category '{args.category}' not found.")
        return
    if not sup:
        print(f"Supplier '{args.supplier}' not found.")
        return
    if args.barcode and Product.query.filter_by(barcode=args.barcode).first():
        print(f"Product with barcode '{args.barcode}' already exists.")
        return
    prod = Product(
        name=args.name,
        barcode=args.barcode,
        category_id=cat.id,
        supplier_id=sup.id,
        purchase_price=args.purchase_price,
        selling_price=args.selling_price,
        quantity=args.quantity,
        reorder_level=args.reorder_level,
        expiry_date=datetime.strptime(args.expiry_date, '%Y-%m-%d').date() if args.expiry_date else None,
    )
    db.session.add(prod)
    db.session.commit()
    print(f"Product '{prod.name}' added with id {prod.id}.")


def cmd_list_products(args):
    prods = Product.query.order_by(Product.created_at.desc()).all()
    for p in prods:
        cat = Category.query.get(p.category_id)
        sup = Supplier.query.get(p.supplier_id)
        print(f"[{p.id}] {p.name} | Barcode: {p.barcode or '-'} | Qty: {p.quantity} | Cat: {cat.name if cat else '-'} | Supplier: {sup.name if sup else '-'}")
    print(f"Total products: {len(prods)}")


def cmd_add_task(args):
    task = ChatTask(title=args.title, status='open')
    db.session.add(task)
    db.session.commit()
    print(f"Task '{task.title}' added with id {task.id}.")


def cmd_list_tasks(args):
    q = ChatTask.query
    if args.status:
        q = q.filter_by(status=args.status)
    tasks = q.order_by(ChatTask.created_at.desc()).all()
    for t in tasks:
        print(f"[{t.id}] {t.title} - {t.status}")
    print(f"Total tasks: {len(tasks)}")


def cmd_complete_task(args):
    t = ChatTask.query.get(args.id)
    if not t:
        print(f"Task id {args.id} not found.")
        return
    t.status = 'done'
    t.updated_at = datetime.utcnow()
    db.session.commit()
    print(f"Task id {t.id} marked as done.")


def build_parser():
    parser = argparse.ArgumentParser(description='GMS Database Management CLI')
    sub = parser.add_subparsers(dest='command')

    # seed
    p_seed = sub.add_parser('seed', help='Seed categories, suppliers, and sample products')
    p_seed.set_defaults(func=cmd_seed)

    # category commands
    p_add_cat = sub.add_parser('add_category', help='Add a category')
    p_add_cat.add_argument('--name', required=True)
    p_add_cat.add_argument('--description', default='')
    p_add_cat.set_defaults(func=cmd_add_category)

    p_list_cat = sub.add_parser('list_categories', help='List categories')
    p_list_cat.set_defaults(func=cmd_list_categories)

    # supplier commands
    p_add_sup = sub.add_parser('add_supplier', help='Add a supplier')
    p_add_sup.add_argument('--name', required=True)
    p_add_sup.add_argument('--contact_person', default='')
    p_add_sup.add_argument('--email', default='')
    p_add_sup.add_argument('--phone', required=True)
    p_add_sup.add_argument('--address', default='')
    p_add_sup.set_defaults(func=cmd_add_supplier)

    p_list_sup = sub.add_parser('list_suppliers', help='List suppliers')
    p_list_sup.set_defaults(func=cmd_list_suppliers)

    # product commands
    p_add_prod = sub.add_parser('add_product', help='Add a product')
    p_add_prod.add_argument('--name', required=True)
    p_add_prod.add_argument('--barcode', default='')
    p_add_prod.add_argument('--category', required=True, help='Category name')
    p_add_prod.add_argument('--supplier', required=True, help='Supplier name')
    p_add_prod.add_argument('--purchase_price', type=float, required=True)
    p_add_prod.add_argument('--selling_price', type=float, required=True)
    p_add_prod.add_argument('--quantity', type=int, default=0)
    p_add_prod.add_argument('--reorder_level', type=int, default=10)
    p_add_prod.add_argument('--expiry_date', help='YYYY-MM-DD', default='')
    p_add_prod.set_defaults(func=cmd_add_product)

    p_list_prod = sub.add_parser('list_products', help='List products')
    p_list_prod.set_defaults(func=cmd_list_products)

    # task commands
    p_add_task = sub.add_parser('add_task', help='Add a task')
    p_add_task.add_argument('--title', required=True)
    p_add_task.set_defaults(func=cmd_add_task)

    p_list_task = sub.add_parser('list_tasks', help='List tasks')
    p_list_task.add_argument('--status', choices=['open', 'in_progress', 'done'])
    p_list_task.set_defaults(func=cmd_list_tasks)

    p_complete_task = sub.add_parser('complete_task', help='Complete a task by id')
    p_complete_task.add_argument('--id', type=int, required=True)
    p_complete_task.set_defaults(func=cmd_complete_task)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not hasattr(args, 'func'):
        parser.print_help()
        return
    with app.app_context():
        ensure_tables()
        args.func(args)


if __name__ == '__main__':
    main()