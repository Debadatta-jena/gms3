from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models.order import Order, OrderItem
from models.product import Product
from datetime import datetime
import uuid
from app import db

order_bp = Blueprint('order', __name__, url_prefix='/orders')

@order_bp.route('/')
@login_required
def index():
    orders = Order.query.order_by(Order.order_date.desc()).all()
    return render_template('order/index.html', orders=orders)

@order_bp.route('/new', methods=['GET', 'POST'])
@login_required
def new():
    if request.method == 'POST':
        customer_name = request.form['customer_name']
        customer_phone = request.form.get('customer_phone', '')
        customer_email = request.form.get('customer_email', '')
        payment_method = request.form['payment_method']
        payment_status = request.form['payment_status']
        notes = request.form.get('notes', '')
        
        # Generate unique order number
        order_number = f"ORD-{uuid.uuid4().hex[:8].upper()}"
        
        # Create order
        order = Order(
            order_number=order_number,
            order_date=datetime.now(),
            customer_name=customer_name,
            customer_phone=customer_phone,
            customer_email=customer_email,
            payment_method=payment_method,
            payment_status=payment_status,
            notes=notes,
            created_by=current_user.id
        )
        
        db.session.add(order)
        db.session.flush()  # Get the order ID
        
        # Process order items
        product_ids = request.form.getlist('product_id[]')
        quantities = request.form.getlist('quantity[]')
        prices = request.form.getlist('price[]')
        
        total_amount = 0
        
        for i in range(len(product_ids)):
            if product_ids[i] and quantities[i] and prices[i]:
                product_id = int(product_ids[i])
                quantity = int(quantities[i])
                price = float(prices[i])
                
                # Get product
                product = Product.query.get(product_id)
                if not product:
                    continue
                
                # Check if enough stock
                if product.quantity < quantity:
                    flash(f'Not enough stock for {product.name}. Available: {product.quantity}', 'danger')
                    db.session.rollback()
                    return redirect(url_for('order.new'))
                
                # Create order item
                item = OrderItem(
                    order_id=order.id,
                    product_id=product_id,
                    quantity=quantity,
                    unit_price=price,
                    subtotal=quantity * price
                )
                
                # Update product quantity
                product.quantity -= quantity
                
                db.session.add(item)
                total_amount += item.subtotal
        
        # Update order total
        order.total_amount = total_amount
        
        db.session.commit()
        flash('Order created successfully!', 'success')
        return redirect(url_for('order.view', id=order.id))
    
    products = Product.query.filter(Product.quantity > 0).all()
    return render_template('order/new.html', products=products)

@order_bp.route('/view/<int:id>')
@login_required
def view(id):
    order = Order.query.get_or_404(id)
    return render_template('order/view.html', order=order)

@order_bp.route('/invoice/<int:id>')
@login_required
def invoice(id):
    order = Order.query.get_or_404(id)
    return render_template('order/invoice.html', order=order)

@order_bp.route('/update-status/<int:id>', methods=['POST'])
@login_required
def update_status(id):
    order = Order.query.get_or_404(id)
    payment_status = request.form['payment_status']
    
    order.payment_status = payment_status
    db.session.commit()
    
    flash('Order payment status updated successfully!', 'success')
    return redirect(url_for('order.view', id=id))

@order_bp.route('/cancel/<int:id>', methods=['POST'])
@login_required
def cancel(id):
    order = Order.query.get_or_404(id)
    
    # Return products to inventory
    for item in order.items:
        product = Product.query.get(item.product_id)
        if product:
            product.quantity += item.quantity
    
    order.status = 'cancelled'
    db.session.commit()
    
    flash('Order cancelled successfully!', 'success')
    return redirect(url_for('order.index'))

@order_bp.route('/api/product/<int:id>')
@login_required
def get_product(id):
    product = Product.query.get_or_404(id)
    
    return jsonify({
        'id': product.id,
        'name': product.name,
        'selling_price': product.selling_price,
        'quantity': product.quantity
    })