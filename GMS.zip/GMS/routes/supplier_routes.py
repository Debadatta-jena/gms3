from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models.supplier import Supplier, SupplierOrder, SupplierOrderItem
from models.product import Product
from datetime import datetime
from app import db

supplier_bp = Blueprint('supplier', __name__, url_prefix='/suppliers')

@supplier_bp.route('/')
@login_required
def index():
    suppliers = Supplier.query.all()
    return render_template('supplier/index.html', suppliers=suppliers)

@supplier_bp.route('/new', methods=['GET', 'POST'])
@login_required
def new():
    if request.method == 'POST':
        name = request.form['name']
        contact_person = request.form['contact_person']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']
        
        supplier = Supplier(
            name=name,
            contact_person=contact_person,
            email=email,
            phone=phone,
            address=address
        )
        
        db.session.add(supplier)
        db.session.commit()
        flash('Supplier added successfully!', 'success')
        return redirect(url_for('supplier.index'))
    
    return render_template('supplier/new.html')

@supplier_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit(id):
    supplier = Supplier.query.get_or_404(id)
    
    if request.method == 'POST':
        supplier.name = request.form['name']
        supplier.contact_person = request.form['contact_person']
        supplier.email = request.form['email']
        supplier.phone = request.form['phone']
        supplier.address = request.form['address']
        
        db.session.commit()
        flash('Supplier updated successfully!', 'success')
        return redirect(url_for('supplier.index'))
    
    return render_template('supplier/edit.html', supplier=supplier)

@supplier_bp.route('/delete/<int:id>', methods=['POST'])
@login_required
def delete(id):
    supplier = Supplier.query.get_or_404(id)
    
    # Check if supplier has products
    if supplier.products:
        flash('Cannot delete supplier with associated products!', 'danger')
        return redirect(url_for('supplier.index'))
    
    db.session.delete(supplier)
    db.session.commit()
    flash('Supplier deleted successfully!', 'success')
    return redirect(url_for('supplier.index'))

@supplier_bp.route('/view/<int:id>')
@login_required
def view(id):
    supplier = Supplier.query.get_or_404(id)
    products = Product.query.filter_by(supplier_id=id).all()
    orders = SupplierOrder.query.filter_by(supplier_id=id).order_by(SupplierOrder.order_date.desc()).all()
    
    return render_template('supplier/view.html', supplier=supplier, products=products, orders=orders)

@supplier_bp.route('/orders')
@login_required
def orders():
    orders = SupplierOrder.query.order_by(SupplierOrder.order_date.desc()).all()
    return render_template('supplier/orders.html', orders=orders)

@supplier_bp.route('/orders/new', methods=['GET', 'POST'])
@login_required
def new_order():
    if request.method == 'POST':
        supplier_id = request.form['supplier_id']
        expected_delivery_date = datetime.strptime(request.form['expected_delivery_date'], '%Y-%m-%d')
        notes = request.form['notes']
        
        # Create supplier order
        order = SupplierOrder(
            supplier_id=supplier_id,
            order_date=datetime.now(),
            expected_delivery_date=expected_delivery_date,
            status='pending',
            notes=notes,
            created_by=current_user.id
        )
        
        db.session.add(order)
        db.session.flush()  # Get the order ID
        
        # Process order items
        product_ids = request.form.getlist('product_id[]')
        quantities = request.form.getlist('quantity[]')
        costs = request.form.getlist('cost[]')
        
        for i in range(len(product_ids)):
            if product_ids[i] and quantities[i] and costs[i]:
                item = SupplierOrderItem(
                    order_id=order.id,
                    product_id=int(product_ids[i]),
                    quantity=int(quantities[i]),
                    cost_price=float(costs[i])
                )
                db.session.add(item)
        
        db.session.commit()
        flash('Supplier order created successfully!', 'success')
        return redirect(url_for('supplier.orders'))
    
    suppliers = Supplier.query.all()
    products = Product.query.all()
    return render_template('supplier/new_order.html', suppliers=suppliers, products=products)

@supplier_bp.route('/orders/view/<int:id>')
@login_required
def view_order(id):
    order = SupplierOrder.query.get_or_404(id)
    return render_template('supplier/view_order.html', order=order)

@supplier_bp.route('/orders/update-status/<int:id>', methods=['POST'])
@login_required
def update_order_status(id):
    order = SupplierOrder.query.get_or_404(id)
    status = request.form['status']
    
    if status == 'received':
        # Update product quantities when order is received
        for item in order.items:
            product = Product.query.get(item.product_id)
            if product:
                product.quantity += item.quantity
                # Update product cost price if it has changed
                if item.cost_price != product.cost_price:
                    product.cost_price = item.cost_price
        
        order.received_date = datetime.now()
    
    order.status = status
    db.session.commit()
    
    flash('Order status updated successfully!', 'success')
    return redirect(url_for('supplier.view_order', id=id))

@supplier_bp.route('/api/products/<int:supplier_id>')
@login_required
def get_supplier_products(supplier_id):
    products = Product.query.filter_by(supplier_id=supplier_id).all()
    
    results = []
    for product in products:
        results.append({
            'id': product.id,
            'name': product.name,
            'cost_price': product.cost_price
        })
    
    return jsonify(results)