from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from models.order import Order, OrderItem
from models.product import Product, Category
from models.supplier import Supplier, SupplierOrder
from sqlalchemy import func, extract
from datetime import datetime, timedelta
import pandas as pd
from app import db

report_bp = Blueprint('report', __name__, url_prefix='/reports')

@report_bp.route('/')
@login_required
def index():
    return render_template('report/index.html')

@report_bp.route('/sales')
@login_required
def sales_report():
    # Get date range from request
    start_date_str = request.args.get('start_date')
    end_date_str = request.args.get('end_date')
    
    # Default to last 30 days if not provided
    if not start_date_str:
        start_date = datetime.now() - timedelta(days=30)
    else:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
    
    if not end_date_str:
        end_date = datetime.now()
    else:
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
    
    # Query sales data
    sales_data = db.session.query(
        Order.order_date,
        func.sum(Order.total_amount).label('total_sales'),
        func.count(Order.id).label('order_count')
    ).filter(
        Order.order_date.between(start_date, end_date)
    ).group_by(
        Order.order_date
    ).order_by(
        Order.order_date
    ).all()
    
    # Query top products
    top_products = db.session.query(
        Product.name,
        func.sum(OrderItem.quantity).label('total_quantity'),
        func.sum(OrderItem.subtotal).label('total_sales')
    ).join(
        OrderItem, Product.id == OrderItem.product_id
    ).join(
        Order, OrderItem.order_id == Order.id
    ).filter(
        Order.order_date.between(start_date, end_date)
    ).group_by(
        Product.id
    ).order_by(
        func.sum(OrderItem.subtotal).desc()
    ).limit(10).all()
    
    # Query sales by category
    category_sales = db.session.query(
        Category.name,
        func.sum(OrderItem.subtotal).label('total_sales')
    ).join(
        Product, Category.id == Product.category_id
    ).join(
        OrderItem, Product.id == OrderItem.product_id
    ).join(
        Order, OrderItem.order_id == Order.id
    ).filter(
        Order.order_date.between(start_date, end_date)
    ).group_by(
        Category.id
    ).order_by(
        func.sum(OrderItem.subtotal).desc()
    ).all()
    
    # Calculate summary statistics
    total_sales = sum(item.total_sales for item in sales_data) if sales_data else 0
    total_orders = sum(item.order_count for item in sales_data) if sales_data else 0
    avg_order_value = total_sales / total_orders if total_orders > 0 else 0
    
    # Format dates for display
    formatted_sales_data = [
        {
            'date': item.order_date.strftime('%Y-%m-%d'),
            'total_sales': float(item.total_sales),
            'order_count': item.order_count
        }
        for item in sales_data
    ]
    
    return render_template(
        'report/sales.html',
        start_date=start_date.strftime('%Y-%m-%d'),
        end_date=end_date.strftime('%Y-%m-%d'),
        sales_data=formatted_sales_data,
        top_products=top_products,
        category_sales=category_sales,
        total_sales=total_sales,
        total_orders=total_orders,
        avg_order_value=avg_order_value
    )

@report_bp.route('/inventory')
@login_required
def inventory_report():
    # Query inventory data
    inventory_data = db.session.query(
        Category.name.label('category'),
        func.count(Product.id).label('product_count'),
        func.sum(Product.quantity).label('total_quantity'),
        func.sum(Product.quantity * Product.cost_price).label('inventory_value')
    ).join(
        Product, Category.id == Product.category_id
    ).group_by(
        Category.id
    ).order_by(
        func.sum(Product.quantity * Product.cost_price).desc()
    ).all()
    
    # Query low stock products
    low_stock_products = Product.query.filter(Product.quantity <= Product.reorder_level).all()
    
    # Query expiring products (next 30 days)
    thirty_days_from_now = datetime.now() + timedelta(days=30)
    expiring_products = Product.query.filter(
        Product.expiry_date <= thirty_days_from_now,
        Product.expiry_date >= datetime.now()
    ).order_by(Product.expiry_date).all()
    
    # Calculate summary statistics
    total_products = sum(item.product_count for item in inventory_data) if inventory_data else 0
    total_inventory_value = sum(item.inventory_value for item in inventory_data) if inventory_data else 0
    
    return render_template(
        'report/inventory.html',
        inventory_data=inventory_data,
        low_stock_products=low_stock_products,
        expiring_products=expiring_products,
        total_products=total_products,
        total_inventory_value=total_inventory_value
    )

@report_bp.route('/suppliers')
@login_required
def supplier_report():
    # Query supplier data
    supplier_data = db.session.query(
        Supplier.name,
        func.count(Product.id).label('product_count'),
        func.count(SupplierOrder.id).label('order_count')
    ).outerjoin(
        Product, Supplier.id == Product.supplier_id
    ).outerjoin(
        SupplierOrder, Supplier.id == SupplierOrder.supplier_id
    ).group_by(
        Supplier.id
    ).order_by(
        func.count(Product.id).desc()
    ).all()
    
    # Query recent supplier orders
    recent_orders = SupplierOrder.query.order_by(SupplierOrder.order_date.desc()).limit(10).all()
    
    return render_template(
        'report/suppliers.html',
        supplier_data=supplier_data,
        recent_orders=recent_orders
    )

@report_bp.route('/api/sales-by-date')
@login_required
def api_sales_by_date():
    # Get date range from request
    start_date_str = request.args.get('start_date')
    end_date_str = request.args.get('end_date')
    
    # Default to last 30 days if not provided
    if not start_date_str:
        start_date = datetime.now() - timedelta(days=30)
    else:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
    
    if not end_date_str:
        end_date = datetime.now()
    else:
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
    
    # Query sales data
    sales_data = db.session.query(
        Order.order_date,
        func.sum(Order.total_amount).label('total_sales')
    ).filter(
        Order.order_date.between(start_date, end_date)
    ).group_by(
        Order.order_date
    ).order_by(
        Order.order_date
    ).all()
    
    # Format for JSON response
    result = [
        {
            'date': item.order_date.strftime('%Y-%m-%d'),
            'total_sales': float(item.total_sales)
        }
        for item in sales_data
    ]
    
    return jsonify(result)

@report_bp.route('/api/sales-by-category')
@login_required
def api_sales_by_category():
    # Get date range from request
    start_date_str = request.args.get('start_date')
    end_date_str = request.args.get('end_date')
    
    # Default to last 30 days if not provided
    if not start_date_str:
        start_date = datetime.now() - timedelta(days=30)
    else:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
    
    if not end_date_str:
        end_date = datetime.now()
    else:
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
    
    # Query sales by category
    category_sales = db.session.query(
        Category.name,
        func.sum(OrderItem.subtotal).label('total_sales')
    ).join(
        Product, Category.id == Product.category_id
    ).join(
        OrderItem, Product.id == OrderItem.product_id
    ).join(
        Order, OrderItem.order_id == Order.id
    ).filter(
        Order.order_date.between(start_date, end_date)
    ).group_by(
        Category.id
    ).order_by(
        func.sum(OrderItem.subtotal).desc()
    ).all()
    
    # Format for JSON response
    result = [
        {
            'category': item.name,
            'total_sales': float(item.total_sales)
        }
        for item in category_sales
    ]
    
    return jsonify(result)