from flask import Blueprint, jsonify, request, session
from flask_login import login_required, current_user
from utils.ai_engine import AIEngine
from utils.llm_client import LLMClient
from utils.offline_chatbot import OfflineChatbot
from models.product import Product
from models.order import Order, OrderItem
from models.chat import ChatMessage, ChatTask
from app import db
from datetime import datetime, timedelta
import re

ai_bp = Blueprint('ai', __name__, url_prefix='/api/ai')

@ai_bp.route('/predict/sales/<int:product_id>')
@login_required
def predict_sales(product_id):
    """Predict sales for a specific product"""
    days = int(request.args.get('days', 7))
    
    try:
        product = Product.query.get_or_404(product_id)
        ai_engine = AIEngine(db)
        predictions = ai_engine.predict_sales(product_id, days_ahead=days)
        
        if predictions:
            return jsonify({
                'status': 'success',
                'product': product.name,
                'predictions': predictions
            })
        else:
            return jsonify({
                'status': 'error',
                'message': 'Not enough data to make predictions'
            }), 400
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@ai_bp.route('/insights/seasonal')
@login_required
def seasonal_insights():
    """Get seasonal insights"""
    try:
        ai_engine = AIEngine(db)
        trends = ai_engine.get_seasonal_trends()
        
        return jsonify({
            'status': 'success',
            'trends': trends
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@ai_bp.route('/insights/customer-interests')
@login_required
def customer_interests():
    """Get customer interest insights"""
    try:
        ai_engine = AIEngine(db)
        interests = ai_engine.get_customer_interests()
        
        return jsonify({
            'status': 'success',
            'interests': interests
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@ai_bp.route('/dashboard/insights')
@login_required
def dashboard_insights():
    """Get AI insights for dashboard"""
    try:
        ai_engine = AIEngine(db)
        insights = ai_engine.generate_insights()
        
        return jsonify({
            'status': 'success',
            'insights': insights
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@ai_bp.route('/chat', methods=['POST'])
@login_required
def chat():
    """Advanced offline AI chatbot endpoint with NLP, ML predictions, and context awareness.
    Accepts JSON: { message: string }
    Returns: { status: string, reply: string, intent?: string, data?: object, suggestions?: list }
    """
    data = request.get_json(silent=True) or {}
    message = (data.get('message') or '').strip()
    
    if not message:
        return jsonify({'status': 'error', 'message': 'No message provided'}), 400

    try:
        # Initialize offline chatbot
        chatbot = OfflineChatbot(db)
        
        # Handle conversation reset
        if message.lower() in ('reset', 'clear', 'clear chat', 'reset chat'):
            chatbot.clear_conversation()
            return jsonify({
                'status': 'success',
                'reply': '🔄 Conversation reset. Hello! I\'m your AI assistant for the Grocery Management System. How can I help you today?',
                'intent': 'reset',
                'suggestions': [
                    'Show current stock levels',
                    'Sales report for today',
                    'Low stock alerts',
                    'Predict next week sales'
                ]
            })
        
        # Process message with offline chatbot
        response_data = chatbot.process_message(message, user_id=str(current_user.id))
        
        # Save user message to database
        try:
            user_msg = ChatMessage(
                user_id=current_user.id,
                role='user',
                content=message,
                created_at=datetime.now()
            )
            db.session.add(user_msg)
            
            # Save bot response to database
            bot_msg = ChatMessage(
                user_id=current_user.id,
                role='assistant',
                content=response_data['response'],
                created_at=datetime.now()
            )
            db.session.add(bot_msg)
            db.session.commit()
            
        except Exception as e:
            db.session.rollback()
            # Continue even if database save fails
            pass
        
        # Format response for frontend
        response = {
            'status': 'success',
            'reply': response_data['response'],
            'intent': response_data.get('intent'),
            'timestamp': datetime.now().isoformat(),
            'context': response_data.get('context'),
            'is_follow_up': response_data.get('is_follow_up', False)
        }
        
        # Add suggestions if available
        if 'suggestions' in response_data:
            response['suggestions'] = response_data['suggestions']
        
        # Add data if available (for charts, tables, etc.)
        if response_data.get('data'):
            response['data'] = response_data['data']
        
        return jsonify(response)
        
    except Exception as e:
        # Fallback to basic response on error
        return jsonify({
            'status': 'error',
            'reply': f'❌ I apologize, but I encountered an error: {str(e)}. Please try rephrasing your question.',
            'intent': 'error',
            'suggestions': [
                'Try a simpler question',
                'Check stock levels',
                'View sales report',
                'Get help'
            ]
        }), 500