from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models.product import Product, Category
from models.supplier import Supplier
from datetime import datetime, timedelta
import os
from werkzeug.utils import secure_filename
from app import db

product_bp = Blueprint('product', __name__, url_prefix='/products')

@product_bp.route('/')
@login_required
def index():
    products = Product.query.all()
    return render_template('product/index.html', products=products)

@product_bp.route('/low-stock')
@login_required
def low_stock():
    # Get products with quantity below reorder level
    products = Product.query.filter(Product.quantity <= Product.reorder_level).all()
    return render_template('product/low_stock.html', products=products)

@product_bp.route('/expiring-soon')
@login_required
def expiring_soon():
    # Get products expiring in the next 30 days
    thirty_days_from_now = datetime.now() + timedelta(days=30)
    products = Product.query.filter(Product.expiry_date <= thirty_days_from_now).all()
    return render_template('product/expiring_soon.html', products=products)

@product_bp.route('/new', methods=['GET', 'POST'])
@login_required
def new():
    if request.method == 'POST':
        name = request.form['name']
        barcode = request.form['barcode']
        category_id = request.form['category_id']
        supplier_id = request.form['supplier_id']
        cost_price = float(request.form['cost_price'])
        selling_price = float(request.form['selling_price'])
        quantity = int(request.form['quantity'])
        reorder_level = int(request.form['reorder_level'])
        expiry_date = datetime.strptime(request.form['expiry_date'], '%Y-%m-%d') if request.form['expiry_date'] else None
        description = request.form['description']
        
        # Handle image upload
        image_path = None
        if 'image' in request.files and request.files['image'].filename:
            image = request.files['image']
            filename = secure_filename(image.filename)
            # Ensure directory exists
            os.makedirs('static/uploads/products', exist_ok=True)
            image_path = os.path.join('uploads/products', filename)
            image.save(os.path.join('static', image_path))
        
        product = Product(
            name=name,
            barcode=barcode,
            category_id=category_id,
            supplier_id=supplier_id,
            cost_price=cost_price,
            selling_price=selling_price,
            quantity=quantity,
            reorder_level=reorder_level,
            expiry_date=expiry_date,
            description=description,
            image_path=image_path
        )
        
        db.session.add(product)
        db.session.commit()
        flash('Product added successfully!', 'success')
        return redirect(url_for('product.index'))
    
    categories = Category.query.all()
    suppliers = Supplier.query.all()
    return render_template('product/new.html', categories=categories, suppliers=suppliers)

@product_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit(id):
    product = Product.query.get_or_404(id)
    
    if request.method == 'POST':
        product.name = request.form['name']
        product.barcode = request.form['barcode']
        product.category_id = request.form['category_id']
        product.supplier_id = request.form['supplier_id']
        product.cost_price = float(request.form['cost_price'])
        product.selling_price = float(request.form['selling_price'])
        product.quantity = int(request.form['quantity'])
        product.reorder_level = int(request.form['reorder_level'])
        product.expiry_date = datetime.strptime(request.form['expiry_date'], '%Y-%m-%d') if request.form['expiry_date'] else None
        product.description = request.form['description']
        
        # Handle image upload
        if 'image' in request.files and request.files['image'].filename:
            image = request.files['image']
            filename = secure_filename(image.filename)
            # Ensure directory exists
            os.makedirs('static/uploads/products', exist_ok=True)
            image_path = os.path.join('uploads/products', filename)
            image.save(os.path.join('static', image_path))
            product.image_path = image_path
        
        db.session.commit()
        flash('Product updated successfully!', 'success')
        return redirect(url_for('product.index'))
    
    categories = Category.query.all()
    suppliers = Supplier.query.all()
    return render_template('product/edit.html', product=product, categories=categories, suppliers=suppliers)

@product_bp.route('/delete/<int:id>', methods=['POST'])
@login_required
def delete(id):
    product = Product.query.get_or_404(id)
    db.session.delete(product)
    db.session.commit()
    flash('Product deleted successfully!', 'success')
    return redirect(url_for('product.index'))

@product_bp.route('/categories')
@login_required
def categories():
    categories = Category.query.all()
    return render_template('product/categories.html', categories=categories)

@product_bp.route('/categories/new', methods=['GET', 'POST'])
@login_required
def new_category():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        
        category = Category(name=name, description=description)
        db.session.add(category)
        db.session.commit()
        flash('Category added successfully!', 'success')
        return redirect(url_for('product.categories'))
    
    return render_template('product/new_category.html')

@product_bp.route('/categories/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_category(id):
    category = Category.query.get_or_404(id)
    
    if request.method == 'POST':
        category.name = request.form['name']
        category.description = request.form['description']
        
        db.session.commit()
        flash('Category updated successfully!', 'success')
        return redirect(url_for('product.categories'))
    
    return render_template('product/edit_category.html', category=category)

@product_bp.route('/categories/delete/<int:id>', methods=['POST'])
@login_required
def delete_category(id):
    category = Category.query.get_or_404(id)
    
    # Check if category has products
    if category.products:
        flash('Cannot delete category with associated products!', 'danger')
        return redirect(url_for('product.categories'))
    
    db.session.delete(category)
    db.session.commit()
    flash('Category deleted successfully!', 'success')
    return redirect(url_for('product.categories'))

@product_bp.route('/api/search', methods=['GET'])
@login_required
def search_products():
    query = request.args.get('q', '')
    products = Product.query.filter(Product.name.ilike(f'%{query}%')).all()
    
    results = []
    for product in products:
        results.append({
            'id': product.id,
            'name': product.name,
            'barcode': product.barcode,
            'selling_price': product.selling_price,
            'quantity': product.quantity,
            'category': product.category.name if product.category else 'None'
        })
    
    return jsonify(results)

@product_bp.route('/api/barcode/<barcode>', methods=['GET'])
@login_required
def get_product_by_barcode(barcode):
    product = Product.query.filter_by(barcode=barcode).first()
    
    if not product:
        return jsonify({'error': 'Product not found'}), 404
    
    return jsonify({
        'id': product.id,
        'name': product.name,
        'barcode': product.barcode,
        'selling_price': product.selling_price,
        'quantity': product.quantity,
        'category': product.category.name if product.category else 'None'
    })