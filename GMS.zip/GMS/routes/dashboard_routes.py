from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from models.product import Product
from models.order import Order, OrderItem
from models.supplier import Supplier
from datetime import datetime, timedelta
from sqlalchemy import func
from app import db
from utils.ai_engine import AIEngine

dashboard_bp = Blueprint('dashboard', __name__, url_prefix='/dashboard')

@dashboard_bp.route('/')
@login_required
def index():
    # Get counts for dashboard
    product_count = Product.query.count()
    low_stock_count = Product.query.filter(Product.quantity <= Product.reorder_level).count()
    order_count = Order.query.count()
    supplier_count = Supplier.query.count()
    
    # Get recent orders
    recent_orders = Order.query.order_by(Order.order_date.desc()).limit(5).all()
    
    # Get low stock products
    low_stock_products = Product.query.filter(Product.quantity <= Product.reorder_level).limit(5).all()
    
    # Get sales data for chart
    end_date = datetime.now()
    start_date = end_date - timedelta(days=7)
    
    sales_data = db.session.query(
        func.date(Order.order_date).label('date'),
        func.sum(Order.total_amount).label('total')
    ).filter(
        Order.order_date.between(start_date, end_date)
    ).group_by(
        func.date(Order.order_date)
    ).all()
    
    dates = []
    sales = []
    
    for data in sales_data:
        dates.append(data.date.strftime('%Y-%m-%d'))
        sales.append(float(data.total))
    
    # Generate AI insights
    ai_insights = generate_ai_insights()
    
    return render_template('dashboard/index.html',
                          title='Dashboard',
                          product_count=product_count,
                          low_stock_count=low_stock_count,
                          order_count=order_count,
                          supplier_count=supplier_count,
                          recent_orders=recent_orders,
                          low_stock_products=low_stock_products,
                          dates=dates,
                          sales=sales,
                          ai_insights=ai_insights)

def generate_ai_insights():
    """Generate AI-powered insights for the dashboard"""
    # Try to use the AI engine for insights
    try:
        ai_engine = AIEngine(db)
        ai_insights = ai_engine.generate_insights()
        if ai_insights:
            return ai_insights
    except Exception as e:
        print(f"Error generating AI insights: {str(e)}")
    
    # Fallback to basic insights if AI engine fails
    insights = []
    
    # Get top selling products
    top_products = db.session.query(
        Product.name,
        func.sum(OrderItem.quantity).label('total_quantity')
    ).join(
        OrderItem, Product.id == OrderItem.product_id
    ).group_by(
        Product.id
    ).order_by(
        func.sum(OrderItem.quantity).desc()
    ).limit(3).all()
    
    if top_products:
        top_product_names = [p.name for p in top_products]
        insights.append(f"Top selling products: {', '.join(top_product_names)}")
    
    # Low stock alerts
    low_stock = Product.query.filter(Product.quantity <= Product.reorder_level).all()
    if low_stock:
        insights.append(f"Alert: {len(low_stock)} products are low in stock and need reordering")
    
    # Expiring products
    today = datetime.now().date()
    expiring_soon = Product.query.filter(
        Product.expiry_date <= today + timedelta(days=30),
        Product.expiry_date > today
    ).all()
    if expiring_soon:
        insights.append(f"Warning: {len(expiring_soon)} products will expire in the next 30 days")
    
    # Seasonal prediction (simplified)
    current_month = datetime.now().month
    if current_month in [11, 12]:  # November, December
        insights.append("Seasonal insight: Prepare for holiday season by stocking up on festive items")
    elif current_month in [1, 2]:  # January, February
        insights.append("Seasonal insight: Winter essentials are likely to see increased demand")
    elif current_month in [6, 7, 8]:  # June, July, August
        insights.append("Seasonal insight: Summer products are trending this season")
    
    return insights

@dashboard_bp.route('/api/sales-data')
@login_required
def sales_data():
    """API endpoint for sales data"""
    days = int(request.args.get('days', 30))
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=days)
    
    sales_data = db.session.query(
        func.date(Order.order_date).label('date'),
        func.sum(Order.total_amount).label('total')
    ).filter(
        func.date(Order.order_date) >= start_date,
        func.date(Order.order_date) <= end_date
    ).group_by(
        func.date(Order.order_date)
    ).all()
    
    result = {
        'labels': [],
        'data': []
    }
    
    for sale in sales_data:
        result['labels'].append(sale.date.strftime('%Y-%m-%d'))
        result['data'].append(float(sale.total))
    
    return jsonify(result)

@dashboard_bp.route('/ai-predictions')
@login_required
def ai_predictions():
    """Show AI predictions and insights"""
    try:
        ai_engine = AIEngine(db)
        
        # Get seasonal trends
        seasonal_trends = ai_engine.get_seasonal_trends()
        
        # Get product predictions for top products
        top_products = db.session.query(
            Product.id,
            Product.name,
            func.sum(OrderItem.quantity).label('total_quantity')
        ).join(
            OrderItem, Product.id == OrderItem.product_id
        ).group_by(
            Product.id
        ).order_by(
            func.sum(OrderItem.quantity).desc()
        ).limit(5).all()
        
        product_predictions = {}
        for product in top_products:
            predictions = ai_engine.predict_sales(product.id, days_ahead=7)
            if predictions:
                product_predictions[product.name] = predictions
        
        return render_template(
            'dashboard/ai_predictions.html',
            seasonal_trends=seasonal_trends,
            product_predictions=product_predictions
        )
    except Exception as e:
        flash(f"Error generating AI predictions: {str(e)}", "danger")
        return redirect(url_for('dashboard.index'))